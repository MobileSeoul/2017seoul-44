from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager

import logger
import resource


def create_app():
    """
    Creates Flask instance & initialize

    Flask best practice : Application Factories
    - Use 'application factory', 'current_app'

    # What's the big deal?
    1. Testing
    2. Multiple instances running in one process
    3. from app import app -> circular imports

    :return: app
    :rtype: Flask
    """
    app = Flask(__name__)
    app.config.from_pyfile('config.py')

    CORS(app)
    JWTManager(app)

    logger.decorate(app)
    resource.deploy(app)

    return app

_app = create_app()


if __name__ == '__main__':
    # threading.Thread(target=tour_api.parse).start()
    _app.run(port=_app.config['PORT'], threaded=True, debug=True)
