from mongoengine import *

connect('seoul_people')
