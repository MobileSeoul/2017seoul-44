from db.mongo import *


class ChatModel(EmbeddedDocument):
    topic = StringField(primary_key=True)
    title = StringField(required=True)


class MapPinModel(Document):
    topic = StringField(required=True)
    content_id = IntField(required=True)
    owner = StringField(required=True)
    title = StringField(required=True)
    x = FloatField(required=True)
    y = FloatField(required=True)
