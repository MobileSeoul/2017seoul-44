import os

from papago import Translator

ts = Translator(os.getenv('PAPAGO_ID'), os.getenv('PAPAGO_KEY'))


# noinspection PyBroadException
def translate(text):
    try:
        return ts.translate(text, 'ko', 'en').text
    except:
        return ''
