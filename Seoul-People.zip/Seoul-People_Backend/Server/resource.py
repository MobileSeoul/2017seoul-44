from flask import Blueprint, Flask
from flask_restful_swagger_2 import Api

from routes.api.auth.auth import Auth

from routes.api.chat.chat import Chat, ChatInvitation
from routes.api.chat.map import MapPins

from routes.api.tour.tour_detail import TourDetail
from routes.api.tour.tour_list import CategorizedTourList, SearchedTourList
from routes.api.tour.tour_main_page import MainPage

from routes.api.user.after_signup import FindID, FindPW, Withdraw, MyPage
from routes.api.user.friend import Friend, FriendInvitation, ReceivedFriendInvitation
from routes.api.user.signup import EmailCertify, EmailCheck, Signup, FacebookSignup
from routes.api.user.user_search import UserSearch
from routes.api.user.wish import WishList


def deploy(app):
    """
    Add resources to Flask instance

    :param app: flask.Flask instance

    :type app: Flask

    :rtype: None
    """
    blueprint = Blueprint('API', __name__)
    api = Api(blueprint, api_version=app.config['API_VER'], title=app.config['API_TITLE'], description=app.config['API_DESC'])

    api.add_resource(Auth, '/auth')

    api.add_resource(Chat, '/chat')
    api.add_resource(ChatInvitation, '/chat/invite')
    api.add_resource(MapPins, '/chat/pin')

    api.add_resource(TourDetail, '/tour-detail')
    api.add_resource(CategorizedTourList, '/tour-list/categorized')
    api.add_resource(SearchedTourList, '/tour-list/searched')
    api.add_resource(MainPage, '/tour-list/main')

    api.add_resource(FindID, '/find-id')
    api.add_resource(FindPW, '/find-pw')
    api.add_resource(Withdraw, '/withdraw')
    api.add_resource(MyPage, '/mypage')

    api.add_resource(Friend, '/friend')
    api.add_resource(FriendInvitation, '/friend-invite')
    api.add_resource(ReceivedFriendInvitation, '/friend-invite/received')

    api.add_resource(EmailCertify, '/certify/email')
    api.add_resource(EmailCheck, '/check/email')
    api.add_resource(Signup, '/signup')
    api.add_resource(FacebookSignup, '/signup/facebook')

    api.add_resource(UserSearch, '/user-search')

    api.add_resource(WishList, '/wish-list')

    app.register_blueprint(blueprint)
