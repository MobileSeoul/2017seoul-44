AUTH_POST = {
    'tags': ['로그인'],
    'description': '로그인',
    'responses': {
        '201': {
            'description': '로그인 성공',
            'examples': {
                'application/json': {
                    'access_token': 'aaaaaa.bbbbbb.cccccc'
                }
            }
        },
        '400': {
            'description': '로그인 실패 - 요청 데이터 문제',
            'examples': {
                'application/json : Request is not JSON': {
                    'msg': 'Missing JSON in request'
                },
                'application/json : Missing id': {
                    'msg': 'Missing id parameter'
                },
                'application/json : Missing pw': {
                    'msg': 'Missing pw parameter'
                }
            }
        },
        '401': {
            'description': '로그인 실패',
            'examples': {
                'application/json': {
                    'msg': 'Incorrect id or password'
                }
            }
        }
    }
}
