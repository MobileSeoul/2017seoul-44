from flask_jwt_extended import create_access_token
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.user import AccountModel

from . import auth_doc


class Auth(Resource):
    @swagger.doc(auth_doc.AUTH_POST)
    def post(self):
        """
        로그인
        """
        if not request.is_json:
            return {
                'msg': 'Missing JSON in request'
            }, 400

        id = request.json.get('id', None)
        pw = request.json.get('pw', None)

        if not id:
            return {
                'msg': 'Missing id parameter'
            }, 400

        if not pw:
            return {
                'msg': 'Missing pw parameter'
            }, 400

        if id and id.startswith('fb_') and AccountModel.objects(id=id):
            # Facebook, PW is not required
            return {
                'access_token': create_access_token(identity=id)
            }, 201

        elif id and pw and AccountModel.objects(id=id, pw=pw):
            return {
                'access_token': create_access_token(identity=id)
            }, 201

        else:
            return {
               'msg': 'Incorrect id or password'
            }, 401
