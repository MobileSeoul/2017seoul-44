MAIN_PAGE_GET = {
    'tags': ['여행지 리스트'],
    'description': '메인 페이지를 위한 여행지 리스트',
    'parameters': [
        {
            'name': 'Authorization',
            'description': 'JWT Token',
            'in': 'header',
            'type': 'str',
            'required': True
        },
        {
            'name': 'popular_len',
            'description': '이달의 인기만점 조회 갯수',
            'in': 'query',
            'type': 'int',
            'required': True
        },
        {
            'name': 'monthly_len',
            'description': '이달의 가볼만한 곳 조회 갯수',
            'in': 'query',
            'type': 'int',
            'required': True
        },
        {
            'name': 'festival_len',
            'description': '최상단에 위치할 축제 정보 조회 갯수',
            'in': 'query',
            'type': 'int',
            'required': True
        }
    ],
    'responses': {
        '200': {
            'description': '조회 성공',
            'examples': {
                'application/json': {
                    'festival': [
                        {
                            'content_id': 737479,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '강남 페스티벌 2017',
                            'title_eng': 'Festival, 2017.'
                        },
                        {
                            'content_id': 1307813,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '강동선사문화축제 2017',
                            'title_eng': 'Gangdong prehistoric culture festival 2017'
                        },
                        {
                            'content_id': 406664,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '갈갈이패밀리 개그콘서트',
                            'title_eng': 'Galgari Family Gag Concert'
                        },
                        {
                            'content_id': 1155897,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '개화산 해맞이 행사 2017',
                            'title_eng': 'Appreciate Gaehwasan 2017 event.'
                        },
                        {
                            'content_id': 1806376,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '강동톡페스티벌 2017',
                            'title_eng': 'Gangdong Festival, a 2017'
                        }
                    ],
                    'monthly': [
                        {
                            'address': '서울특별시 용산구 한강대로 253',
                            'content_id': 142718,
                            'content_type_id': 32,
                            'image': 'http://***',
                            'title': '가야관광호텔',
                            'title_eng': 'Kaya Tourist Hotel',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 송파구 송파대로28길 5',
                            'content_id': 142785,
                            'content_type_id': 32,
                            'image': 'http://***',
                            'title': '가락관광호텔',
                            'title_eng': 'Garak Tourist Hotel',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 강서구 곰달래로 247',
                            'content_id': 1747824,
                            'content_type_id': 32,
                            'image': 'http://***',
                            'title': '㈜코스테이',
                            'title_eng': 'Tei Corp., the course',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 종로구 대학로8가길 111',
                            'content_id': 406664,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '갈갈이패밀리 개그콘서트',
                            'title_eng': 'Galgari Family Gag Concert',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 강동구 올림픽로 875',
                            'content_id': 1307813,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '강동선사문화축제 2017',
                            'title_eng': 'Gangdong prehistoric culture festival 2017',
                            'wish_count': 0,
                            'wished': False
                        }
                    ],
                    'popular': [
                        {
                            'address': '서울특별시 중구 을지로 281',
                            'content_id': 130511,
                            'content_type_id': 14,
                            'image': 'http://***',
                            'title': '간송미술관',
                            'title_eng': 'Gansong Art Museum',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 강남구 영동대로 513',
                            'content_id': 737479,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '강남 페스티벌 2017',
                            'title_eng': 'Festival, 2017.',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 송파구 양재대로 932',
                            'content_id': 132215,
                            'content_type_id': 38,
                            'image': 'http://***',
                            'title': '가락시장(가락농수산물 도매시장)',
                            'title_eng': 'Garak Market (Garak Agricultural and Marine Products Wholesale Market)',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 강동구 올림픽로 875',
                            'content_id': 1307813,
                            'content_type_id': 15,
                            'image': 'http://***',
                            'title': '강동선사문화축제 2017',
                            'title_eng': 'Gangdong prehistoric culture festival 2017',
                            'wish_count': 0,
                            'wished': False
                        },
                        {
                            'address': '서울특별시 용산구 한강대로 253',
                            'content_id': 142718,
                            'content_type_id': 32,
                            'image': 'http://***',
                            'title': '가야관광호텔',
                            'title_eng': 'Kaya Tourist Hotel',
                            'wish_count': 0,
                            'wished': False
                        }
                    ]
                }
            }
        }
    }
}
