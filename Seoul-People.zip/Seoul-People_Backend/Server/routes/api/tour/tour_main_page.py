from flask_jwt_extended import get_jwt_identity, jwt_required
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.tour_base import TourTopModel
from db.models.user import AccountModel
from routes.api.tour import tour_main_page_doc
from support.api_interactions.papago_api import translate


class MainPage(Resource):
    @swagger.doc(tour_main_page_doc.MAIN_PAGE_GET)
    @jwt_required
    def get(self):
        """
        메인 페이지를 위한 여행지 리스트 조회
        """
        festival_len = request.args.get('festival_len', type=int, default=5)
        popular_len = request.args.get('popular_len', type=int, default=5)
        monthly_len = request.args.get('monthly_len', type=int, default=5)

        client_wish_list = AccountModel.objects(id=get_jwt_identity()).first().wish_list

        festival_list = TourTopModel.objects(content_type_id=15)
        festival_list = sorted(festival_list, key=lambda k: k.views, reverse=True)[:festival_len]

        popular_list = TourTopModel.objects
        popular_list = sorted(popular_list, key=lambda k: k.views, reverse=True)[:popular_len]

        monthly_list = TourTopModel.objects
        monthly_list = sorted(monthly_list, key=lambda k: k.wish_count, reverse=True)[:monthly_len]

        return {
            'festival': [{
                'content_id': festival.content_id,
                'content_type_id': festival.content_type_id,
                'image': festival.image,
                'title': festival.title,
                'title_eng': translate(festival.title)
            } for festival in festival_list],
            'popular': [{
                'content_id': popular.content_id,
                'content_type_id': popular.content_type_id,
                'image': popular.image,
                'title': popular.title,
                'title_eng': translate(popular.title),
                'address': popular.address,
                'wish_count': popular.wish_count,
                'wished': popular.content_id in client_wish_list
            } for popular in popular_list],
            'monthly': [{
                'content_id': monthly.content_id,
                'content_type_id': monthly.content_type_id,
                'image': monthly.image,
                'title': monthly.title,
                'title_eng': translate(monthly.title),
                'address': monthly.address,
                'wish_count': monthly.wish_count,
                'wished': monthly.content_id in client_wish_list
            } for monthly in monthly_list]
        }, 200
