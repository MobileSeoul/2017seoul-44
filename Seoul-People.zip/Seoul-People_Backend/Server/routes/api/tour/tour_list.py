import math

from flask import Response
from flask_jwt_extended import get_jwt_identity, jwt_required
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.tour_base import TourTopModel
from db.models.user import AccountModel
from routes.api.tour import tour_list_doc


def detect(tour_list, sort_type, x=0.0, y=0.0):
    client_wish_list = AccountModel.objects(id=get_jwt_identity()).first().wish_list

    if sort_type == 1:
        # 조회순
        tour_list = sorted(tour_list, key=lambda k: k.views, reverse=True)
    elif sort_type == 2:
        # 위시리스트 많은 순
        tour_list = sorted(tour_list, key=lambda k: k.wish_count, reverse=True)
    elif sort_type == 3:
        # 거리순
        for tour in tour_list:
            tour.distance = math.sqrt(math.pow(tour.x - x, 2) + math.pow(tour.y - y, 2))

        tour_list = sorted(tour_list, key=lambda k: k.distance)

    return [{
        'content_id': tour.content_id,
        'content_type_id': tour.content_type_id,
        'title': tour.title,
        'address': tour.address,
        'category': tour.small_category,
        'image': tour.image,
        'wish_count': tour.wish_count,
        'wished': tour.content_id in client_wish_list
    } for tour in tour_list]


class SearchedTourList(Resource):
    @swagger.doc(tour_list_doc.SEARCHED_TOUR_LIST_GET)
    @jwt_required
    def get(self):
        """
        검색 기반 여행지 리스트 조회
        """
        keyword = request.args.get('keyword')
        sort_type = request.args.get('sort_type', type=int)
        page = request.args.get('page', type=int)

        tour_list = detect([tour for tour in TourTopModel.objects if keyword in tour.title], sort_type, request.args.get('x', type=float, default=0.0), request.args.get('y', type=float, default=0.0))
        # After keyword filtering

        if tour_list:
            return tour_list[8 * (page - 1):8 * page + 1]
        else:
            return Response('', 204)


class CategorizedTourList(Resource):
    @swagger.doc(tour_list_doc.CATEGORIZED_TOUR_LIST_GET)
    @jwt_required
    def get(self):
        """
        카테고리 기반 여행지 리스트 조회
        """
        category = request.args.get('category')
        sort_type = request.args.get('sort_type', type=int)
        page = request.args.get('page', type=int)

        tour_list = detect([tour for tour in TourTopModel.objects if category == tour.small_category], sort_type, request.args.get('x', type=float, default=0.0), request.args.get('y', type=float, default=0.0))

        if tour_list:
            return tour_list[8 * (page - 1):8 * page + 1]
        else:
            return Response('', 204)
