from flask import Response
from flask_jwt_extended import get_jwt_identity, jwt_required
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.chat import MapPinModel
from db.models.tour_base import TourTopModel
from db.models.user import AccountModel
from routes.api.chat import map_doc


class MapPins(Resource):
    @swagger.doc(map_doc.MAP_PINS_POST)
    @jwt_required
    def post(self):
        """
        채팅방 지도에 핀 등록
        """
        topic = request.form.get('topic')
        content_id = request.form.get('content_id', type=int)

        if MapPinModel.objects(topic=topic, content_id=content_id):
            # Already exists
            return Response('', 204)

        tour = TourTopModel.objects(content_id=content_id).first()
        title, x, y = tour.title, tour.x, tour.y
        name = AccountModel.objects(id=get_jwt_identity()).first().name

        MapPinModel(topic=topic, content_id=content_id, owner=name, title=title, x=x, y=y).save()

        return Response('', 201)

    @swagger.doc(map_doc.MAP_PINS_GET)
    @jwt_required
    def get(self):
        """
        채팅방의 핀 리스트 조회
        """
        topic = request.form.get('topic')

        if not MapPinModel.objects(topic=topic):
            return Response('', 204)

        return [{
            'content_id': pin.content_id,
            'owner': pin.name,
            'title': pin.title,
            'x': pin.x,
            'y': pin.y
        } for pin in MapPinModel.objects(topic=topic)], 200

    @swagger.doc(map_doc.MAP_PINS_DELETE)
    @jwt_required
    def delete(self):
        """
        채팅방의 핀 제거
        """
        topic = request.form.get('topic')
        content_id = request.form.get('content_id', type=int)

        MapPinModel.objects(topic=topic, content_id=content_id).first().delete()

        return Response('', 200)
