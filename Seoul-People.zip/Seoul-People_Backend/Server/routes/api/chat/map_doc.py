MAP_PINS_POST = {
    'tags': ['채팅 내 지도'],
    'description': '지도에 새로운 핀 추가',
    'parameters': [
        {
            'name': 'topic',
            'description': '채팅방의 topic',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'content_id',
            'description': '추가할 핀(여행지)의 content id',
            'in': 'formData',
            'type': 'int',
            'required': True
        },
        {
            'name': 'Authorization',
            'description': 'JWT Token',
            'in': 'header',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '201': {
            'description': '핀 추가 성공'
        },
        '204': {
            'description': '핀 추가 실패(이미 추가한 핀)'
        }
    }
}

MAP_PINS_GET = {
    'tags': ['채팅 내 지도'],
    'description': '채팅방의 모든 핀 포인트 조회',
    'parameters': [
        {
            'name': 'topic',
            'description': '채팅방의 topic',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'Authorization',
            'description': 'JWT Token',
            'in': 'header',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '200': {
            'description': '핀 포인트 조회 성공',
            'examples': {
                'application/json': [

                ]
            }
        },
        '204': {
            'description': '존재하는 핀 포인트 없음'
        }
    }
}

MAP_PINS_DELETE = {
    'tags': ['채팅 내 지도'],
    'description': '핀 포인트 제거',
    'parameters': [
        {
            'name': 'Authorization',
            'description': 'JWT Token',
            'in': 'header',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '200': {
            'description': '핀 제거 성공'
        }
    }
}
