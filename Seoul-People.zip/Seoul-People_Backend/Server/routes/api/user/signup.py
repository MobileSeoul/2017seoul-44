import json
import os
import random
from email.mime.text import MIMEText
from smtplib import SMTP
from urllib.request import urlopen

from flask import Response
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.user import AccountModel, CertifyModel
from routes.api.user import signup_doc


class EmailCheck(Resource):
    @swagger.doc(signup_doc.EMAIL_CHECK_POST)
    def post(self):
        """
        이메일 중복 체크
        """
        if AccountModel.objects(email=request.form.get('email')):
            return Response('', 204)
        else:
            return Response('', 201)


def get_certify_code():
    return int('%06d' % random.randint(0, 999999))


def send_certify_mail(dst_email, code):
    smtp_id = os.getenv('SMTP_ID')
    smtp_pw = os.getenv('SMTP_PW')

    smtp = SMTP('smtp.naver.com', 587)
    smtp.starttls()
    smtp.login(smtp_id, smtp_pw)

    message = MIMEText('Code : {0}'.format(code), _charset='utf-8')
    message['subject'] = '[서울사람] 이메일 인증 코드입니다.'
    message['from'] = smtp_id + '@naver.com'
    message['to'] = dst_email

    smtp.sendmail(smtp_id + '@naver.com', dst_email, message.as_string())
    smtp.quit()


class EmailCertify(Resource):
    @swagger.doc(signup_doc.EMAIL_CERTIFY_POST)
    def post(self):
        """
        이메일 인증
        """
        email = request.form.get('email')
        code = request.form.get('code', type=int)

        if CertifyModel.objects(identity=email, code=code):
            CertifyModel.objects(identity=email).first().delete()

            return Response('', 201)
        else:
            return Response('', 204)

    @swagger.doc(signup_doc.EMAIL_CERTIFY_GET)
    def get(self):
        """
        이메일 인증 코드 발급
        """
        email = request.args.get('email')
        code = get_certify_code()

        CertifyModel(identity=email, code=code).save()
        send_certify_mail(email, code)

        return Response('', 200)


class Signup(Resource):
    @swagger.doc(signup_doc.SIGNUP_POST)
    def post(self):
        """
        회원가입
        """
        id = request.form.get('id')
        pw = request.form.get('pw')
        registration_id = request.form.get('registration_id')
        email = request.form.get('email', default=None)
        phone = request.form.get('phone', default=None)
        name = request.form.get('name')

        if AccountModel.objects(id=id):
            return Response('', 204)
        else:
            AccountModel.objects(registration_id=registration_id).delete()
            AccountModel(id=id, pw=pw, registration_id=registration_id, email=email, phone=phone, name=name).save()

            return Response('', 201)


class FacebookSignup(Resource):
    @swagger.doc(signup_doc.FACEBOOK_SIGNUP_POST)
    def post(self):
        """
        페이스북 회원가입
        """
        fb_id = 'fb_' + request.form.get('fb_id')
        access_token = request.form.get('access_token')
        registration_id = request.form.get('registration_id')
        phone = request.form.get('phone', default=None)

        resp = urlopen('https://graph.facebook.com/v2.10/{0}?access_token={1}'.format(fb_id, access_token))
        if AccountModel.objects(id=fb_id) and AccountModel.objects(id=fb_id).first().pw is None:
            # 이미 가입되어 있는 페이스북 계정
            return Response('', 204)
        elif resp.code == 400:
            return Response('', 400)
        else:
            body = json.loads(resp.read().decode('utf-8'))
            name = body['name']
            email = body['email']

            AccountModel(id=fb_id, registration_id=registration_id, email=email, phone=phone, name=name).save()

            return {'id': fb_id}, 201
