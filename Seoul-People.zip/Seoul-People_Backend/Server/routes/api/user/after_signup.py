import os
import random
from email.mime.text import MIMEText
from smtplib import SMTP

from flask import Response
from flask_jwt_extended import get_jwt_identity, jwt_required
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.user import AccountModel, CertifyModel
from routes.api.user import after_signup_doc


def get_certify_code():
    return int('%06d' % random.randint(0, 999999))


def send_certify_mail(dst_email, code):
    smtp_id = os.getenv('SMTP_ID')
    smtp_pw = os.getenv('SMTP_PW')

    smtp = SMTP('smtp.naver.com', 587)
    smtp.starttls()
    smtp.login(smtp_id, smtp_pw)

    message = MIMEText('Code : {0}'.format(code), _charset='utf-8')
    message['subject'] = '[대전사람] 이메일 인증 코드입니다.'
    message['from'] = smtp_id + '@naver.com'
    message['to'] = dst_email

    smtp.sendmail(smtp_id + '@naver.com', dst_email, message.as_string())
    smtp.quit()


class FindID(Resource):
    @swagger.doc(after_signup_doc.FIND_ID_POST)
    def post(self):
        """
        ID 찾기 - 이메일 인증
        """
        email = request.form.get('email', default=None)
        code = request.form.get('code', type=int)

        if CertifyModel.objects(identity=email, code=code):
            CertifyModel.objects(identity=email, code=code).first().delete()

            return {'id': AccountModel.objects(email=email).first().id}, 201
        else:
            return Response('', 204)

    @swagger.doc(after_signup_doc.FIND_ID_GET)
    def get(self):
        """
        ID 찾기 - 이메일 인증 코드 발급
        """
        email = request.args.get('email', default=None)
        code = get_certify_code()

        if email and AccountModel.objects(email=email):
            CertifyModel(identity=email, code=code).save()
            send_certify_mail(email, code)

            return Response('', 200)
        else:
            return Response('', 204)


class FindPW(Resource):
    def get(self):
        pass

    def post(self):
        pass


class Withdraw(Resource):
    @swagger.doc(after_signup_doc.WITHDRAW_POST)
    @jwt_required
    def post(self):
        """
        회원 탈퇴
        """
        AccountModel.objects(id=get_jwt_identity()).first().delete()

        return Response('', 201)


class MyPage(Resource):
    @swagger.doc(after_signup_doc.MYPAGE_GET)
    @jwt_required
    def get(self):
        """
        마이페이지
        """
        user = AccountModel.objects(id=get_jwt_identity()).first()

        if not user:
            return Response('', 204)
        else:
            return {
                'name': user.name,
                'email': user.email,
                'phone': user.phone
            }, 200
