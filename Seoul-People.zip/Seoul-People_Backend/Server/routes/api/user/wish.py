from flask import Response
from flask_jwt_extended import get_jwt_identity, jwt_required
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.tour_base import TourTopModel
from db.models.user import AccountModel
from routes.api.user import wish_doc


class WishList(Resource):
    @swagger.doc(wish_doc.WISH_POST)
    @jwt_required
    def post(self):
        """
        위시 리스트에 여행지 추가
        """
        content_id = request.form.get('content_id', type=int)

        if not TourTopModel.objects(content_id=content_id)\
                or content_id in AccountModel.objects(id=get_jwt_identity()).first().wish_list:
            # Content id does not exist, or Already in wish list
            return Response('', 200)
        else:
            wish_list = list(AccountModel.objects(id=get_jwt_identity()).first().wish_list)
            wish_list.append(content_id)
            # New wish list

            AccountModel.objects(id=get_jwt_identity()).first().update(wish_list=wish_list)

            tour = TourTopModel.objects(content_id=content_id).first()
            tour.update(wish_count=tour.wish_count + 1)

            return Response('', 201)

    @swagger.doc(wish_doc.WISH_GET)
    @jwt_required
    def get(self):
        """
        위시 리스트 조회
        """
        return list(AccountModel.objects(id=get_jwt_identity()).first().wish_list), 200

    @swagger.doc(wish_doc.WISH_DELETE)
    @jwt_required
    def delete(self):
        """
        위시 리스트에서 여행지 삭제
        """
        content_id = request.form.get('content_id', type=int)

        wish_list = list(set(list(AccountModel.objects(id=get_jwt_identity()).first().wish_list)))
        del wish_list[wish_list.index(content_id)]
        AccountModel.objects(id=get_jwt_identity()).first().update(wish_list=wish_list)

        return Response('', 200)
