from flask import Response
from flask_jwt_extended import get_jwt_identity, jwt_required
from flask_restful_swagger_2 import Resource, request, swagger

from db.models.friend import FriendRequestsModel
from db.models.user import AccountModel
from routes.api.user import friend_doc


class Friend(Resource):
    @swagger.doc(friend_doc.FRIEND_GET)
    @jwt_required
    def get(self):
        """
        친구 리스트 조회
        """
        friends = AccountModel.objects(id=get_jwt_identity()).first().friends

        if friends:
            return friends, 200
        else:
            return Response('', 204)

    @swagger.doc(friend_doc.FRIEND_DELETE)
    @jwt_required
    def delete(self):
        """
        친구 삭제
        """
        friend_id = request.form.get('friend_id')

        friends = AccountModel.objects(id=get_jwt_identity()).first().friends
        try:
            del friends[friends.index(friend_id)]
        except ValueError:
            pass

        AccountModel.objects(id=get_jwt_identity()).first().update(friends=friends)

        return Response('', 200)


class FriendInvitation(Resource):
    # 요청자 관점
    @swagger.doc(friend_doc.FRIEND_INVITATION_POST)
    @jwt_required
    def post(self):
        """
        친구 요청
        """
        receiver_id = request.form.get('receiver_id')

        if FriendRequestsModel.objects(requester_id=get_jwt_identity(), receiver_id=receiver_id):
            return Response('', 204)
        else:
            FriendRequestsModel(requester_id=get_jwt_identity(), receiver_id=receiver_id).save()

            return Response('', 201)

    @swagger.doc(friend_doc.FRIEND_INVITATION_GET)
    @jwt_required
    def get(self):
        """
        송신한 친구 요청 목록
        """
        friend_requests = FriendRequestsModel.objects(requester_id=get_jwt_identity())

        if friend_requests:
            return [friend_request.receiver_id for friend_request in friend_requests], 200
        else:
            return Response('', 204)

    @swagger.doc(friend_doc.FRIEND_INVITATION_DELETE)
    @jwt_required
    def delete(self):
        """
        친구 요청 취소
        """
        receiver_id = request.form.get('receiver_id')

        FriendRequestsModel.objects(requester_id=get_jwt_identity(), receiver_id=receiver_id).first().delete()

        return Response('', 200)


class ReceivedFriendInvitation(Resource):
    # 수신자 입장
    @swagger.doc(friend_doc.RECEIVED_FRIEND_INVITATION_POST)
    @jwt_required
    def post(self):
        """
        친구 수락
        """
        requester_id = request.form.get('requester_id')

        FriendRequestsModel.objects(requester_id=requester_id, receiver_id=get_jwt_identity()).first().delete()

        friends = list(AccountModel.objects(id=get_jwt_identity()).first().friends)
        friends.append(requester_id)

        AccountModel.objects(id=get_jwt_identity()).first().update(friends=friends)

        return Response('', 201)

    @swagger.doc(friend_doc.RECEIVED_FRIEND_INVITATION_GET)
    @jwt_required
    def get(self):
        """
        친구요청 목록 조회
        """
        friend_requests = FriendRequestsModel.objects(receiver_id=get_jwt_identity())

        if friend_requests:
            return [friend_request.requester_id for friend_request in friend_requests], 200
        else:
            return Response('', 204)

    @swagger.doc(friend_doc.RECEIVED_FRIEND_INVITATION_DELETE)
    @jwt_required
    def delete(self):
        """
        친구 거절
        """
        requester_id = request.form.get('requester_id')

        FriendRequestsModel.objects(requester_id=requester_id, receiver_id=get_jwt_identity()).first().delete()

        return Response('', 200)
