EMAIL_CHECK_POST = {
    'tags': ['회원가입'],
    'description': '이메일 중복 체크',
    'parameters': [
        {
            'name': 'email',
            'description': '중복체크할 이메일 주소(****@****.***)',
            'in': 'formData',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '201': {
            'description': '중복되지 않음'
        },
        '204': {
            'description': '중복됨'
        }
    }
}

EMAIL_CERTIFY_POST = {
    'tags': ['회원가입'],
    'description': '이메일 인증',
    'parameters': [
        {
            'name': 'email',
            'description': '인증 코드를 받은 이메일 주소(****@****.***)',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'code',
            'description': '인증 코드',
            'in': 'formData',
            'type': 'int',
            'required': True
        }
    ],
    'responses': {
        '201': {
            'description': '이메일 인증 성공'
        },
        '204': {
            'description': '이메일 인증 실패'
        }
    }
}

EMAIL_CERTIFY_GET = {
    'tags': ['회원가입'],
    'description': '이메일 인증 코드 발급',
    'parameters': [
        {
            'name': 'email',
            'description': '인증 코드를 발급할 이메일 주소(****@****.***)',
            'in': 'query',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '200': {
            'description': '인증 코드 전송 완료'
        }
    }
}

SIGNUP_POST = {
    'tags': ['회원가입'],
    'description': '회원가입',
    'parameters': [
        {
            'name': 'id',
            'description': '사용자 ID',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'pw',
            'description': '사용자 Password',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'registration_id',
            'description': 'Firebase 토큰',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'email',
            'description': '이메일',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'phone',
            'description': '핸드폰 번호',
            'in': 'formData',
            'type': 'str',
            'required': False
        },
        {
            'name': 'name',
            'description': '사용자 이름',
            'in': 'formData',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '201': {
            'description': '회원가입 성공'
        },
        '204': {
            'description': '회원가입 실패(이미 가입된 아이디)'
        }
    }
}

FACEBOOK_SIGNUP_POST = {
    'tags': ['회원가입'],
    'description': '페이스북으로 회원가입',
    'parameters': [
        {
            'name': 'fb_id',
            'description': '페이스북 ID ex) 100006735372513',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'access_token',
            'description': '사용자 페이스북 계정의 Access Token',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'registration_id',
            'description': 'Firebase 토큰',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'phone',
            'description': '핸드폰 번호',
            'in': 'formData',
            'type': 'str',
            'required': False
        }
    ],
    'responses': {
        '201': {
            'description': '회원가입 성공. 로그인 시 사용할 새로운 ID 반환',
            'examples': {
                'application/json': {
                    'id': 'fb_1205401113'
                }
            }
        },
        '204': {
            'description': '이미 가입되어 있으며 로그인 요청 요망. 로그인 시 사용할 ID 반환',
            'examples': {
                'application/json': {
                    'id': 'fb_1205401113'
                }
            }
        },
        '400': {
            'description': 'Bad Request. 페이스북 ID나 Access Token의 문제일 가능성이 큼'
        }
    }
}
