FIND_ID_POST = {
    'tags': ['회원가입 후'],
    'description': '이메일 인증',
    'parameters': [
        {
            'name': 'email',
            'description': '인증번호를 받은 이메일',
            'in': 'formData',
            'type': 'str',
            'required': True
        },
        {
            'name': 'code',
            'description': '인증번호',
            'in': 'formData',
            'type': 'int',
            'required': True
        }
    ],
    'responses': {
        '201': {
            'description': '인증 성공',
            'examples': {
                'application/json': {
                    "id": "geni429"
                }
            }
        },
        '204': {
            'description': '인증 실패(올바르지 않은 인증번호)'
        }
    }
}

FIND_ID_GET = {
    'tags': ['회원가입 후'],
    'description': '인증번호 전송',
    'parameters': [
        {
            'name': 'email',
            'description': '회원가입 당시 사용한 이메일',
            'in': 'query',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '200': {
            'description': '인증번호 전송 성공'
        },
        '204': {
            'description': '인증번호 전송 실패(가입되지 않은 이메일)'
        }
    }
}

WITHDRAW_POST = {
    'tags': ['회원가입 후'],
    'description': '회원 탈퇴',
    'parameters': [
        {
            'name': 'Authorization',
            'description': 'JWT Token',
            'in': 'header',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '201': {
            'description': '회원 탈퇴 성공'
        }
    }
}

MYPAGE_GET = {
    'tags': ['회원가입 후'],
    'description': '마이페이지',
    'parameters': [
        {
            'name': 'Authorization',
            'description': 'JWT Token',
            'in': 'header',
            'type': 'str',
            'required': True
        }
    ],
    'responses': {
        '200': {
            'description': '마이페이지 정보 조회 성공',
            'examples': {
                'application/json': {
                    'name': '정근철',
                    'email': 'geni429@gmail.com',
                    'phone': '01069696969'
                }
            }
        }
    }
}
