package com.seoulpeopele.seoulpeople.activities;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.seoulpeopele.seoulpeople.R;

/**
 * Created by KimDongGyu on 2017-10-24.
 */

public class FilterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_filter);

        Toolbar toolbar = (Toolbar) findViewById(R.id.filter_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        final EditText editText = findViewById(R.id.filter_edit_text);
        int color = Color.parseColor("#dddddd");
        editText.getBackground().setColorFilter(color, PorterDuff.Mode.SRC_ATOP);

        Button button_back;
        button_back = (Button) findViewById(R.id.filter_back_btn);
        button_back.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}
