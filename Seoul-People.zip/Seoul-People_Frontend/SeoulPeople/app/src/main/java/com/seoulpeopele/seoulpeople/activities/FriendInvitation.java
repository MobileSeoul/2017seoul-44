package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.FriendInvitationAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.FriendInvitationItem;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by geni on 2017. 10. 26..
 */

public class FriendInvitation extends AppCompatActivity {
    private RecyclerView friendList;
    private APIInterface apiInterface;
    private FriendInvitationAdapter adapter;
    private Realm mRealm;
    private ArrayList<FriendInvitationItem> dataSet = new ArrayList<>();
    private Button inviteBtn;
    private Intent mIntent;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_friend_invitation);
        friendList = (RecyclerView) findViewById(R.id.friend_list);
        inviteBtn = (Button)findViewById(R.id.btn_invite);

        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        mIntent = getIntent();

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(final Realm realm) {
                apiInterface.getFriendList(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonArray>() {
                    @Override
                    public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                        adapter = new FriendInvitationAdapter(
                                response.body(),
                                "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken(),
                                getApplicationContext()
                        );
                        friendList.setAdapter(adapter);
                        friendList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    }

                    @Override
                    public void onFailure(Call<JsonArray> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });

        inviteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final JsonArray list = adapter.getCheckList();
                String a;
                for(int i = 0; i < list.size(); i++){
                    if(list.get(i).getAsJsonObject().get("check").getAsBoolean()){
                        apiInterface.inviteFriend(
                                mIntent.getStringExtra("topic"),
                                list.get(i).getAsJsonObject().get("id").getAsString(),
                                list.get(i).getAsJsonObject().get("token").getAsString()
                        ).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {

                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    }

                    if(i == list.size() && list.get(i).getAsJsonObject().get("check").getAsBoolean()){
                        apiInterface.inviteFriend(
                                mIntent.getStringExtra("topic"),
                                list.get(i).getAsJsonObject().get("name").getAsString(),
                                list.get(i).getAsJsonObject().get("token").getAsString()
                        ).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                Intent intent = new Intent(getApplicationContext(), Chatting.class);
                                intent.putExtra("title", mIntent.getStringExtra("title"));
                                intent.putExtra("topic", mIntent.getStringExtra("topic"));
                                intent.putExtra("name", mIntent.getStringExtra("name"));
                                startActivity(intent);
                                finish();
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    } else {
                        Intent intent = new Intent(getApplicationContext(), Chatting.class);
                        intent.putExtra("title", mIntent.getStringExtra("title"));
                        intent.putExtra("topic", mIntent.getStringExtra("topic"));
                        intent.putExtra("name", mIntent.getStringExtra("name"));
                        startActivity(intent);
                        finish();
                    }
                }
            }
        });
    }

    public void onBackBtnClicked(View view){
        finish();
    }
}
