package com.seoulpeopele.seoulpeople.support.item;

import io.realm.RealmObject;

/**
 * Created by geni on 2017. 10. 23..
 */

public class UserCertifyItem extends RealmObject {
    private String userId;
    private String userPw;
    private String accessToken;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserPw() {
        return userPw;
    }

    public void setUserPw(String userPw) {
        this.userPw = userPw;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
