package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.github.ybq.endless.Endless;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.DetailAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.DetailItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Detail extends AppCompatActivity {
    private ArrayList<DetailItem> Dataset = new ArrayList<>();
    private RecyclerView mRecyclerView;
    private DetailAdapter mAdapter;
    private APIInterface apiInterface;
    private View loadingView;
    private Intent mIntent;
    private TextView detailTitle;
    private Realm mRealm;
    Endless endless;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_detail);
        mIntent = getIntent();

        Toolbar toolbar = (Toolbar) findViewById(R.id.detail_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        mRecyclerView = (RecyclerView) findViewById(R.id.tour_list);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        loadingView = View.inflate(this, R.layout.i_detail_loading, null);
        loadingView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        endless = Endless.applyTo(mRecyclerView,
                loadingView
        );
        final Intent intent = getIntent();
        final String category = intent.getStringExtra("category");
        category_key = intent.getStringExtra("category_key");
        Log.d("checkTheDetail", category);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        getData(category, 1);
        endless.setLoadMoreListener(new Endless.LoadMoreListener() {
            @Override
            public void onLoadMore(int page) {
                getData(category, page);
            }
        });
    }

    private String category_key;
    private void getData(String category, final int page){
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
//                mRecyclerView.setAdapter(new DetailAdapter());
                mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            }
        });
        UserCertifyItem certifyItem = mRealm.where(UserCertifyItem.class).findFirst();
        Log.d("token", certifyItem.getAccessToken());
        apiInterface.getTourListCategorized("JWT " + certifyItem.getAccessToken(), category, 1, page).enqueue(new Callback<JsonArray>() {
            @Override
            public void onResponse(Call<JsonArray> call, final Response<JsonArray> response) {
                if(response.code() == 200){
                    Log.d("response", "SUCCESS");
                    JsonArray jsonArray = response.body();
                    Log.d("1561561", "onResponse: "+jsonArray.toString());
                    Dataset = new ArrayList<>();
                    for(int i = 0; i < jsonArray.size(); i++){
                        DetailItem detailItem = new DetailItem();
                        detailItem.setDetail_address(jsonArray.get(i).getAsJsonObject().get("address").toString());
                        detailItem.setDetail_category(jsonArray.get(i).getAsJsonObject().get("category").toString());
                        detailItem.setDetail_content_id(jsonArray.get(i).getAsJsonObject().get("content_id").getAsInt());
                        detailItem.setDetail_cotent_type_id(jsonArray.get(i).getAsJsonObject().get("content_type_id").getAsInt());
                        detailItem.setDetail_image(jsonArray.get(i).getAsJsonObject().get("image").toString());
                        detailItem.setDetail_title(jsonArray.get(i).getAsJsonObject().get("title").toString());
                        detailItem.setDetail_wish_count(jsonArray.get(i).getAsJsonObject().get("wish_count").getAsInt());
                        detailItem.setDetail_wished(jsonArray.get(i).getAsJsonObject().get("wished").getAsBoolean());
                        Dataset.add(detailItem);
                    }
                    if (page == 1) {
                        mAdapter = new DetailAdapter(Dataset, category_key);
                        //mRecyclerView.setAdapter(mAdapter);
                        endless.setAdapter(mAdapter);
                    } else {
                        Timer timer = new Timer();
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mAdapter.addData(Dataset);
                                        endless.loadMoreComplete();
                                    }
                                });
                            }
                        }, 1000*2);
                    }
                }
            }
            @Override
            public void onFailure(Call<JsonArray> call, Throwable t) {
            }
        });
    }

    public void onBackBtnClicked(View view){
        finish();
    }

}
