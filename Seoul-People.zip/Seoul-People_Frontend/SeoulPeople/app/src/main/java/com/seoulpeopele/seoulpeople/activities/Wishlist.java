package com.seoulpeopele.seoulpeople.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.gson.JsonArray;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.WishlistAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.WishlistItem;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Wishlist extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private Realm mRealm;
    private APIInterface apiInterface;
    private ArrayList<WishlistItem> Dataset = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_wishlist);

        mRecyclerView = (RecyclerView)findViewById(R.id.recycler_wishlist);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        apiInterface = APIClient.getClient().create(APIInterface.class);

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(final Realm realm) {
                apiInterface.getWishList(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonArray>() {
                    @Override
                    public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                        if(response.code() == 200){
                            mRecyclerView.setAdapter(new WishlistAdapter(
                                    response.body(),
                                    "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken())
                            );
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonArray> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });
    }
}
