package com.seoulpeopele.seoulpeople.valueobject;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

/**
 * Created by dsm2016 on 2017-10-28.
 */

public class ChattingItem extends RealmObject {
    @PrimaryKey
    @Required
    private String topic;
    private String chatName;
    private RealmList<ChatItem> chatItems;

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getChatName() {
        return chatName;
    }

    public void setChatName(String chatName) {
        this.chatName = chatName;
    }

    public RealmList<ChatItem> getChatItems() {
        return chatItems;
    }

    public void setChatItems(RealmList<ChatItem> chatItems) {
        this.chatItems = chatItems;
    }
}
