package com.seoulpeopele.seoulpeople.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.firebase.Firebase;
import com.seoulpeopele.seoulpeople.support.item.SignInBody;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Signin extends Fragment {
    private View mView;
    private APIInterface apiInterface;
    private CallbackManager callbackManager;
    private Realm mRealm;
    private List<String> permissionNeeds;

    private Button btnSignIn, btnSignInFaceBook;
    private EditText inputId, inputPassword;
    private LoginButton loginButton;

    public Signin() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        callbackManager = CallbackManager.Factory.create();
        mRealm.init(getContext());
        mRealm = Realm.getDefaultInstance();

        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d("loginResult", loginResult+"");
            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {
        mView = inflater.inflate(R.layout.f_sign_in, container, false);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        callbackManager = CallbackManager.Factory.create();
        permissionNeeds = Arrays.asList("email", "public_profile", "AccessToken");

        btnSignIn = (Button)mView.findViewById(R.id.btn_signin);
        btnSignInFaceBook = (Button)mView.findViewById(R.id.btn_signgin_facebook);
        inputId = (EditText)mView.findViewById(R.id.signin_id);
        inputPassword = (EditText)mView.findViewById(R.id.signin_pw);
        loginButton = (LoginButton)mView.findViewById(R.id.facebook_login);

        loginButton.registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        final String accessToken = loginResult.getAccessToken().getToken();
                        Log.d("access Token", accessToken);
                    }

                    @Override
                    public void onCancel() {
                        Log.d("Facebook login", "canceled");
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        Log.v("LoginActivity", exception.getCause().toString());
                    }
                });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final SignInBody body = new SignInBody();
                body.setId(inputId.getText().toString());
                body.setPw(inputPassword.getText().toString());
                apiInterface.doSignIn(body).enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, final Response<JsonObject> response) {
                        if(response.code() != 401){
                            SharedPreferences sharedPreferences = getContext().getSharedPreferences("SharedPreference", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean("isSignIn", true);
                            editor.apply();

                            mRealm.executeTransaction(new Realm.Transaction() {
                                @Override
                                public void execute(Realm realm) {
                                    UserCertifyItem certifyItem = realm.createObject(UserCertifyItem.class);
                                    certifyItem.setUserId(body.getId());
                                    certifyItem.setUserPw(body.getPw());
                                    certifyItem.setAccessToken(response.body().get("access_token").getAsString());
                                }
                            });
                            startActivity(new Intent(mView.getContext(), MainActivity.class));
                            getActivity().finish();
                        } else {
                            Toast.makeText(getContext(), "잘못된 정보를 입력하였습니다", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });

        btnSignInFaceBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view == btnSignInFaceBook){
                    loginButton.performClick();
                }
            }
        });

        return mView;
    }

    @Override
    public void onActivityResult(int requestCode, int responseCode, Intent data) {
        super.onActivityResult(requestCode, responseCode, data);
        Log.d("onActivityResult", "success");
        callbackManager.onActivityResult(requestCode, responseCode, data);
    }
}


//https://stackoverflow.com/questions/31327897/custom-facebook-login-button-android