package com.seoulpeopele.seoulpeople.activities;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.SearchAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.SearchItem;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static java.security.AccessController.getContext;

public class Search extends Activity {
    private SearchAdapter mAdapter = null;
    private ArrayList<SearchItem> arrayListSearch = new ArrayList<>();
    private RecyclerView mRecyclerView;
    private APIInterface apiInterface;
    private Realm mRealm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_search);

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_search);

        //search_back버튼 이벤트
        Button search_back_btn = (Button) findViewById(R.id.search_btn_back);
        search_back_btn.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                //검색창
                finish();
            }
        }) ;
        //Spinner설정
                    Button search_btn = (Button) findViewById(R.id.search_btn);
                    search_btn.setOnClickListener(new Button.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            EditText editText = (EditText)findViewById(R.id.edit_search);
                            String search_result = editText.getText().toString();
                            if ( editText.getText().toString().length() == 0 ) {
                                Toast.makeText(getApplicationContext(), "검색 내용을 입력해주세요.", Toast.LENGTH_LONG).show();
                            } else {

                                apiInterface = APIClient.getClient().create(APIInterface.class);
                                mRealm.init(getApplicationContext());
                                mRealm = Realm.getDefaultInstance();
                                mRealm.executeTransaction(new Realm.Transaction() {
                                    @Override
                                    public void execute(Realm realm) {
//                mRecyclerView.setAdapter(new DetailAdapter());
                                        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                                    }
                                });
                                apiInterface = APIClient.getClient().create(APIInterface.class);
                                UserCertifyItem certifyItem = mRealm.where(UserCertifyItem.class).findFirst();
                                Log.d("token", certifyItem.getAccessToken());
                                apiInterface.getTourListSearched("JWT " + certifyItem.getAccessToken(), search_result, 1 , 1).enqueue(new Callback<JsonArray>() {
                                    @Override
                                    public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                                        if(response.code() == 200){
                                            Log.d("search_success","야 성공했다!!!");
                                            JsonArray jsonArray = response.body();
                                            arrayListSearch.clear();
                                            for(int i = 0; i < jsonArray.size(); i++){
                                                SearchItem searchItem = new SearchItem();
                                                searchItem.setContent_type_id(jsonArray.get(i).getAsJsonObject().get("content_type_id").getAsInt());
                                                searchItem.setContent_id(jsonArray.get(i).getAsJsonObject().get("content_id").getAsInt());
                                                Log.d("checkContentid",jsonArray.get(i).getAsJsonObject().get("content_id").toString());
                                                searchItem.setTitle(jsonArray.get(i).getAsJsonObject().get("title").toString().replaceAll("\"", ""));
                                                searchItem.setWished(jsonArray.get(i).getAsJsonObject().get("wished").getAsBoolean());
                                                searchItem.setWish_count(jsonArray.get(i).getAsJsonObject().get("wish_count").getAsInt());
                                                if(jsonArray.get(i).getAsJsonObject().get("address") == null){
                                                    searchItem.setImage("주소 정보가 없습니다.");
                                                } else{
                                                    searchItem.setAddress(jsonArray.get(i).getAsJsonObject().get("address").toString());
                                                }
                                                searchItem.setCategory(jsonArray.get(i).getAsJsonObject().get("category").toString());
                                                Log.d("Search_category_log",jsonArray.get(i).getAsJsonObject().get("category").toString());
                                                if(jsonArray.get(i).getAsJsonObject().get("image") == null){
                                                    searchItem.setImage("NoImage");
                                                } else {
                                                    searchItem.setImage(jsonArray.get(i).getAsJsonObject().get("image").toString());
                                                }
                                                arrayListSearch.add(searchItem);
                                            }
                                            mAdapter = new SearchAdapter(arrayListSearch, getApplicationContext());
                                            mRecyclerView.setAdapter(mAdapter);

                                        } else {
                                            Log.d("search_error", "ang gi mo thi"+response.code());
                                        }
                                    }
                                    @Override
                                    public void onFailure(Call<JsonArray> call, Throwable t) {
                                        t.printStackTrace();
                                    }
                                });
                                // use this setting to improve performance if you know that changes
                                // in content do not change the layout size of the RecyclerView
                                mRecyclerView.setHasFixedSize(true);
                                // use a linear layout manager
                                RecyclerView.LayoutManager mLayoutManager;
                                mLayoutManager = new LinearLayoutManager(view.getContext());
                                mRecyclerView.setLayoutManager(mLayoutManager);
                            }
                        }
                    }) ;
    }
}