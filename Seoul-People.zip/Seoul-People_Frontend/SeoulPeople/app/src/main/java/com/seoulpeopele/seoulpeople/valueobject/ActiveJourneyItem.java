package com.seoulpeopele.seoulpeople.valueobject;

/**
 * Created by dsm2016 on 2017-10-26.
 */

public class ActiveJourneyItem {

    private String chat_title;
    private String chat_preview;
    private String chat_time;
    private int chat_count;

    public String getChat_title() {
        return chat_title;
    }

    public void setChat_title(String chat_title) {
        this.chat_title = chat_title;
    }

    public String getChat_preview() {
        return chat_preview;
    }

    public void setChat_preview(String chat_preview) {
        this.chat_preview = chat_preview;
    }

    public String getChat_time() {
        return chat_time;
    }

    public void setChat_time(String chat_time) {
        this.chat_time = chat_time;
    }

    public int getChat_count() {
        return chat_count;
    }

    public void setChat_count(int chat_count) {
        this.chat_count = chat_count;
    }
}
