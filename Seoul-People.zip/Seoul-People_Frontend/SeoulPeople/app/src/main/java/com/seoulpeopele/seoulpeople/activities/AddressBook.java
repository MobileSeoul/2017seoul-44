package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.AddressBookAdapter;
import com.seoulpeopele.seoulpeople.adapter.WishlistAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.AddressBookItem;
import com.seoulpeopele.seoulpeople.valueobject.WishlistItem;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddressBook extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private APIInterface apiInterface;
    private Realm mRealm;
    private ArrayList<AddressBookItem> Dataset = new ArrayList<>();
    private Button addFriend;
    private TextView myName, myPhone, myEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_addres_book);

        mRecyclerView = (RecyclerView)findViewById(R.id.recycler_address_book);
        addFriend = (Button)findViewById(R.id.add_friend);
        myName = (TextView)findViewById(R.id.my_name);
        myPhone = (TextView)findViewById(R.id.my_phone);
        myEmail = (TextView)findViewById(R.id.my_email);

        apiInterface = APIClient.getClient().create(APIInterface.class);
        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(final Realm realm) {
                apiInterface.getMyPageInfo(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        myName.setText(response.body().get("name").getAsString());
                        myPhone.setText(response.body().get("phone").getAsString());
                        myEmail.setText(response.body().get("email").getAsString());
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {

                    }
                });
                apiInterface.getFriendList(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonArray>() {
                    @Override
                    public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                        if(response.code() == 200){
                            mRecyclerView.setAdapter(new AddressBookAdapter(
                                    response.body(),
                                    "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken())
                            );
                            mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonArray> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });

        addFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), FriendRequest.class));
                finish();
            }
        });
    }

    public void onBackBtnClicked(View view){
        finish();
    }
}
