package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.JsonArray;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.FriendReceivedAdapter;
import com.seoulpeopele.seoulpeople.adapter.FriendRequestAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by geni on 2017. 10. 26..
 */

public class FriendRequest extends AppCompatActivity {
    private RecyclerView requests, userList;
    private EditText userId;
    private Button searchBtn;

    private Realm mRealm;
    private APIInterface apiInterface;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_friend_request);
        userId = (EditText)findViewById(R.id.edit_search);
        searchBtn = (Button)findViewById(R.id.search_btn);
        requests = (RecyclerView)findViewById(R.id.requests);
        userList = (RecyclerView)findViewById(R.id.search_result);

        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();

        apiInterface = APIClient.getClient().create(APIInterface.class);
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(final Realm realm) {
                apiInterface.getReceivedList(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonArray>() {
                    @Override
                    public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                        if(response.code() == 200){
                            Log.d("response body", response.body()+"");
                            requests.setAdapter(new FriendReceivedAdapter(
                                    response.body(),
                                    "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken())
                            );
                            requests.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonArray> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRealm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        Log.d("userId", userId.getText().toString());
                       userList.setAdapter(new FriendRequestAdapter(
                               userId.getText().toString(),
                               "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken())
                       );
                        userList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    }
                });
            }
        });
    }

    public void onBackBtnClicked(View view){
        startActivity(new Intent(getApplicationContext(), AddressBook.class));
        finish();
    }
}
