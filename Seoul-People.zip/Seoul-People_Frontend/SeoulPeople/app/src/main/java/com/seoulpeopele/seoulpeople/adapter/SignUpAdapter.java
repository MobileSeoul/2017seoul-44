package com.seoulpeopele.seoulpeople.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.activities.Accounts;
import com.seoulpeopele.seoulpeople.activities.Signin;
import com.seoulpeopele.seoulpeople.activities.Signup;
import com.seoulpeopele.seoulpeople.support.firebase.Firebase;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by geni on 2017. 10. 24..
 */

public class SignUpAdapter extends PagerAdapter {
    private Context mContext;
    private FragmentTransaction mTransaction;
    private View mView;
    private final int MAX_POOL_SIZE = 3;
    private SharedPreferences sharedPreferences;
    private APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);;
    private boolean flag = false;
    private Button btnman;
    private Button btnwoman;

    public SignUpAdapter(Context context, View view, FragmentTransaction transaction) {
        mContext = context;
        mTransaction = transaction;
        mView = view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View)object);
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        FirebaseApp.initializeApp(mContext);
        View view = LayoutInflater.from(mContext).inflate(R.layout.f_sign_up1 + position, null);
        if(position == 0){
            final EditText inputName = (EditText)view.findViewById(R.id.edit_name);
            final EditText inputId = (EditText)view.findViewById(R.id.edit_id);
            final EditText inputPw = (EditText)view.findViewById(R.id.edit_pw);
            Button btnNext = (Button)view.findViewById(R.id.btn_next);

            btnNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sharedPreferences = mContext.getSharedPreferences("SP", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("name", inputName.getText().toString());
                    editor.putString("id", inputId.getText().toString());
                    editor.putString("pw", inputPw.getText().toString());
                    editor.apply();
                    Signup.nextBtn(mView);
                }
            });
        } else if(position == 1) {
            Button btnEmailCertify = (Button) view.findViewById(R.id.btn_email_certify);
            Button btnSignup = (Button) view.findViewById(R.id.btn_signup);
            sharedPreferences = mContext.getSharedPreferences("SP", Context.MODE_PRIVATE);

            btnEmailCertify.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Signup.goEmailCertify(mView);
                }
            });

            btnman = (Button)view.findViewById(R.id.btn_man);
            btnman.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(flag==false){
                        v.setSelected(true);
                        flag = true;
                    } else if(flag == true){
                        v.setSelected(false);
                        flag = false;
                    }
                    // normal click action here
                }
            });


            btnwoman = (Button)view.findViewById(R.id.btn_woman);
            btnwoman.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(flag==false){
                        v.setSelected(true);
                        flag = true;
                    } else if(flag == true){
                        v.setSelected(false);
                        flag = false;
                    }
                    // normal click action here
                }
            });


            btnSignup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(sharedPreferences.getBoolean("isCertified", false)) {
                        final SharedPreferences.Editor editor = sharedPreferences.edit();
//                    TelephonyManager t = (TelephonyManager)mContext.getSystemService(Context.TELEPHONY_SERVICE);
//                    String mPhoneNumber = t.getLine1Number();
//                    Log.d("phoneNumber", mPhoneNumber);

                        apiInterface.doSignUp(
                                sharedPreferences.getString("id", "null"),
                                sharedPreferences.getString("pw", "null"),
                                Firebase.getFirebaseToken(),
                                sharedPreferences.getString("email", "null"),
                                "01028962001",
                                sharedPreferences.getString("name", "null")
                        ).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                mTransaction.replace(R.id.fragment_container_accounts, new Signin());
                                mTransaction.commit();
                                editor.clear();
                                editor.apply();
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    } else  {
                        Toast.makeText(mContext, "이메일 인증을 해주세요", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            final Button btnSendCode = (Button)view.findViewById(R.id.btn_admit);
            final View space = view.findViewById(R.id.space);
            final LinearLayout certifyArea = (LinearLayout)view.findViewById(R.id.certify_area);
            final EditText inputEmail = (EditText)view.findViewById(R.id.edit_email);
            final EditText inputCode = (EditText)view.findViewById(R.id.edit_code);

            btnSendCode.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(btnSendCode.getText().toString().equals("인증번호 발송")){
                        apiInterface.getEmailCertifyCode(
                                inputEmail.getText().toString()
                        ).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                space.setVisibility(View.GONE);
                                certifyArea.setVisibility(View.VISIBLE);
                                btnSendCode.setText("확인");
                                Toast.makeText(mContext, "인증번호 전송 완료", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    } else {
                        apiInterface.doEmailCertify(
                                inputEmail.getText().toString(),
                                Integer.parseInt(inputCode.getText().toString())
                        ).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                sharedPreferences = mContext.getSharedPreferences("SP", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("email", inputEmail.getText().toString());
                                editor.putBoolean("isCertified", true);
                                editor.apply();
                                Signup.nextBtn(mView);
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    }
                }
            });
        }
        container.addView(view, 0);
        return view;
    }

    @Override
    public int getCount() {
        return MAX_POOL_SIZE;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }
}
