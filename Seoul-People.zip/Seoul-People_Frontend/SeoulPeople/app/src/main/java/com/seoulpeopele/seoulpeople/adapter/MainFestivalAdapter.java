package com.seoulpeopele.seoulpeople.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.activities.Introduction_Accomodation;
import com.seoulpeopele.seoulpeople.activities.Introduction_Culture;
import com.seoulpeopele.seoulpeople.activities.Introduction_Festival;
import com.seoulpeopele.seoulpeople.activities.Introduction_Leisure;
import com.seoulpeopele.seoulpeople.activities.Introduction_Restaurant;
import com.seoulpeopele.seoulpeople.activities.Introduction_Shopping;
import com.seoulpeopele.seoulpeople.activities.Introduction_Tourism;
import com.seoulpeopele.seoulpeople.activities.Introduction_Travel_Course;
import com.seoulpeopele.seoulpeople.valueobject.MainFestivalItem;

import java.util.ArrayList;

/**
 * Created by KimDongGyu on 2017-10-24.
 */

public class MainFestivalAdapter extends PagerAdapter {

    LayoutInflater inflater;
    private ArrayList<MainFestivalItem> mDataset;
    private Context mContext;

    public MainFestivalAdapter(LayoutInflater inflater, ArrayList<MainFestivalItem> myDataset, Context context) {
        // TODO Auto-generated constructor stub
        this.inflater = inflater;
        this.mDataset = myDataset;
        this.mContext = context;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return mDataset.size();
    }

    @Override
    public Object instantiateItem(final ViewGroup container, final int position) {
        // TODO Auto-generated method stub
        View view = null;
        view = inflater.inflate(R.layout.i_main_viewpager_festival, null);

        TextView titleTextview = (TextView)view.findViewById(R.id.main_viewpager_festival_title);
        titleTextview.setText(mDataset.get(position).getTitle());

        TextView titleEngTextview = (TextView)view.findViewById(R.id.main_viewpager_festival_subtitle);
        titleEngTextview.setText(mDataset.get(position).getTitle_eng());

        ImageView img = (ImageView) view.findViewById(R.id.main_viewpager_festival_background);

        if(mDataset.get(position).getImage().equals("NoImage")){
            Glide.with(mContext).load(R.drawable.bg_no_image).into(img);
        } else {
            String imgUrl = mDataset.get(position).getImage().substring(1, mDataset.get(position).getImage().length() - 1);
            Glide.with(mContext).load(imgUrl).into(img);
            Log.d("url", mDataset.get(position).getImage());
        }

        final int content_type_id = mDataset.get(position).getContent_type_id();
        ImageView btn= (ImageView) view.findViewById(R.id.main_viewpager_festival_background);
        btn.setOnClickListener(new ImageView.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (content_type_id == 12) {
                    Intent intent = new Intent(view.getContext(), Introduction_Tourism.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else if (content_type_id == 14) {
                    Intent intent = new Intent(view.getContext(), Introduction_Culture.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else if (content_type_id == 15) {
                    Intent intent = new Intent(view.getContext(), Introduction_Festival.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else if (content_type_id == 25) {
                    Intent intent = new Intent(view.getContext(), Introduction_Travel_Course.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else if (content_type_id == 28) {
                    Intent intent = new Intent(view.getContext(), Introduction_Leisure.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else if (content_type_id == 32) {
                    Intent intent = new Intent(view.getContext(), Introduction_Accomodation.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else if (content_type_id == 38) {
                    Intent intent = new Intent(view.getContext(), Introduction_Shopping.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else if (content_type_id == 39) {
                    Intent intent = new Intent(view.getContext(), Introduction_Restaurant.class);
                    intent.putExtra("content_id", mDataset.get(position).getContent_id());
                    view.getContext().startActivity(intent);
                } else {
                    Toast.makeText(container.getContext(),"잘못된 접근입니다.", Toast.LENGTH_LONG).show();
                }
            }
        }) ;

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        // TODO Auto-generated method stub
        container.removeView((View)object);
    }

    @Override
    public boolean isViewFromObject(View v, Object obj) {
        // TODO Auto-generated method stub
        return v==obj;
    }

}
