package com.seoulpeopele.seoulpeople.adapter;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.WishlistItem;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by dsm2016 on 2017-10-23.
 */

public class WishlistAdapter extends RecyclerView.Adapter<WishlistAdapter.ViewHolder> {
    private JsonArray mDataset;
    private String mAccessToken;
    private APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);

    public WishlistAdapter(JsonArray dataSet, String accessToken) {
        this.mDataset = dataSet;
        this.mAccessToken = accessToken;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView place_name;
        public TextView place_address;
        public ImageView wish_back_image;

        public ViewHolder(View view) {
            super(view);
            place_name = (TextView)view.findViewById(R.id.text_place_name);
            place_address = (TextView)view.findViewById(R.id.text_place_address);
            wish_back_image = (ImageView)view.findViewById(R.id.wish_back_image);
        }
    }

    @Override
    public WishlistAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.r_wishlist, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final WishlistAdapter.ViewHolder holder, final int position) {
        apiInterface.getTourDetail(mDataset.get(position).getAsInt(), mAccessToken).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                holder.place_name.setText(response.body().get("title").getAsString());
                holder.place_address.setText(response.body().get("address").getAsString());
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
