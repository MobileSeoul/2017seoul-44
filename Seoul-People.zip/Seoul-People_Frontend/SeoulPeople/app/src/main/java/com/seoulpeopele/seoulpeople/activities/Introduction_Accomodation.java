package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.AES;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Introduction_Accomodation extends AppCompatActivity {
    private ImageView bgIntro, card, carriage, pet;
    private ImageButton starBtn;
    private TextView introPlaceName, introPlaceKind, introTime, introCall,
            introPay, introBenikia, introGoodStay, introRoom, introWebPage, introAddress;
    private FloatingActionButton shareBtn;

    private APIInterface apiInterface;
    private Realm mRealm;
    private Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_introduction_accomodation);
        card = (ImageView)findViewById(R.id.card);
        carriage = (ImageView)findViewById(R.id.carriage);
        pet = (ImageView)findViewById(R.id.pet);
        bgIntro = (ImageView)findViewById(R.id.intro_background);
        starBtn = (ImageButton)findViewById(R.id.star);
        introPlaceName = (TextView)findViewById(R.id.intro_placename);
        introPlaceKind = (TextView)findViewById(R.id.placekind);
        introTime = (TextView)findViewById(R.id.intro_time);
        introCall = (TextView)findViewById(R.id.intro_call);
        introPay = (TextView)findViewById(R.id.intro_pay);
        introBenikia = (TextView)findViewById(R.id.intro_benikia);
        introGoodStay = (TextView)findViewById(R.id.intro_goodstay);
        introRoom = (TextView)findViewById(R.id.intro_room);
        introWebPage = (TextView)findViewById(R.id.intro_webpage);
        introAddress = (TextView)findViewById(R.id.intro_address);
        shareBtn = (FloatingActionButton)findViewById(R.id.shareBtn);

        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        mIntent = getIntent();

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                apiInterface.getTourDetail(
                        mIntent.getIntExtra("content_id", 0),
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        introBenikia.setText(response.body().get("benikia").getAsBoolean() ? "있음" : "없음");
                        introGoodStay.setText(response.body().get("goodstay").getAsBoolean() ? "있음" : "없음");
                        introPlaceName.setText(response.body().get("title").getAsString());
                        introAddress.setText(response.body().get("address").getAsString());
                        if(!response.body().get("image").isJsonNull()){
                            Glide.with(getApplicationContext()).load(
                                    response.body().get("image").getAsString()
                            ).into(bgIntro);
                        }
//                        response.body().get("benikia");
//                        response.body().get("capacity");
//                        response.body().get("checkin_time");
//                        response.body().get("checkout_time");
//                        response.body().get("goodstay");
//                        response.body().get("iamge");
//                        response.body().get("tel");
//                        response.body().get("title");
//                        response.body().get("wish_count");
//                        response.body().get("wished");
//                        response.body().get("x");
//                        response.body().get("y");
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {

                    }
                });
            }
        });

        starBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                starBtn.setBackgroundResource(R.drawable.ic_star);
                mRealm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        apiInterface.addWish(
                                mIntent.getIntExtra("content_id", 0),
                                "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                        ).enqueue(new retrofit2.Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                Toast.makeText(getApplicationContext(), "위시리스트에 추가됐습니다", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    }
                });
            }
        });
    }
}
