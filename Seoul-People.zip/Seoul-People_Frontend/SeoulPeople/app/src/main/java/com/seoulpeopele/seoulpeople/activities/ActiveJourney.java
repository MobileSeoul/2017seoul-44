package com.seoulpeopele.seoulpeople.activities;

import android.app.Activity;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.ChatRoomAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.ActiveJourneyItem;
import com.seoulpeopele.seoulpeople.valueobject.ChattingItem;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActiveJourney extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private FloatingActionButton startChattingBtn;
    private RecyclerView.Adapter myAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<ActiveJourneyItem> Dataset = new ArrayList<>();
    private APIInterface apiInterface;
    private Realm mRealm;
    private Activity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_active_journey);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        mActivity = this;

        mRecyclerView = (RecyclerView)findViewById(R.id.recycler_active_journey);
        startChattingBtn = (FloatingActionButton)findViewById(R.id.startChatting);

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(final Realm realm) {
                apiInterface.getMyPageInfo(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        mRecyclerView.setAdapter(new ChatRoomAdapter(
                                realm.where(ChattingItem.class).findAll(),
                                mActivity,
                                response.body().get("name").getAsString()
                        ));
                        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {

                    }
                });
            }
        });

        startChattingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRealm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        apiInterface.getMyPageInfo(
                                "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                        ).enqueue(new retrofit2.Callback<JsonObject>() {
                            @Override
                            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                                Intent intent = new Intent(getApplicationContext(), CreateChatting.class);
                                intent.putExtra("name", response.body().get("name").getAsString());
                                startActivity(intent);
                                finish();
                            }

                            @Override
                            public void onFailure(Call<JsonObject> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    }
                });
            }
        });
    }

    public void onBackBtnClicked(View view){
        finish();
    }
}
