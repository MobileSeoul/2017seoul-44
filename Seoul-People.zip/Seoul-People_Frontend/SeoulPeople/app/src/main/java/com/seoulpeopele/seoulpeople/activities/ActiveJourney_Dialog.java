package com.seoulpeopele.seoulpeople.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.seoulpeopele.seoulpeople.R;

public class ActiveJourney_Dialog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_active_journey);
    }
}
