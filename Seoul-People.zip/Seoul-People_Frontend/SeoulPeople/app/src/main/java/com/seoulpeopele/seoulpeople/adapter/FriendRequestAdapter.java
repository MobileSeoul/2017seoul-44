package com.seoulpeopele.seoulpeople.adapter;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by geni on 2017. 10. 26..
 */

public class FriendRequestAdapter extends RecyclerView.Adapter<FriendRequestAdapter.ViewHolder> {
    private APIInterface apiInterface;
    private String mAccessToken, mUserId;

    public FriendRequestAdapter(String userId, String accessToken){
        this.mUserId = userId;
        this.mAccessToken = accessToken;
    }

    @Override
    public FriendRequestAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.i_friend_request, parent, false);
        return new FriendRequestAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final FriendRequestAdapter.ViewHolder holder, final int position) {
        Log.d("userId", mUserId);
        Log.d("accessToken", mAccessToken);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        apiInterface.getUserInfo(mUserId, mAccessToken).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, final Response<JsonObject> response) {
                holder.userName.setText(response.body().get("name").getAsString());
                holder.userPhone.setText(response.body().get("phone").getAsString());
                holder.userEmail.setText(response.body().get("email").getAsString());
                holder.requestBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        apiInterface.sendFriendRequest(response.body().get("id").getAsString(), mAccessToken).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                holder.area.setVisibility(View.GONE);
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    }
                });
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public int getItemCount() {
        return 1;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView userName, userPhone, userEmail;
        private Button requestBtn;
        private LinearLayout area;

        public ViewHolder(View view){
            super(view);
            userName = (TextView)view.findViewById(R.id.user_name);
            userPhone = (TextView)view.findViewById(R.id.user_phone);
            userEmail = (TextView)view.findViewById(R.id.user_email);
            requestBtn = (Button)view.findViewById(R.id.btn_request);
            area = (LinearLayout)view.findViewById(R.id.friend_request_area);
        }
    }
}
