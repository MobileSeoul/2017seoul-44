package com.seoulpeopele.seoulpeople.adapter;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.valueobject.ChatItem;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import io.realm.RealmList;

/**
 * Created by geni on 2017. 10. 28..
 */

public class ChatLogAdapter extends RecyclerView.Adapter<ChatLogAdapter.ViewHolder> {
    private ArrayList<ChatItem> mDataSet;

    public ChatLogAdapter(ArrayList<ChatItem> dataSet){
        this.mDataSet = dataSet;
    }

    @Override
    public ChatLogAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.r_chatting, parent, false);
        return new ChatLogAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ChatLogAdapter.ViewHolder holder, int position) {
        holder.userName.setText(mDataSet.get(position).getUserName());
        holder.message.setText(mDataSet.get(position).getMessage());
        holder.time.setText(mDataSet.get(position).getTime());
    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView userName;
        private TextView time;
        private TextView message;

        public ViewHolder(View view){
            super(view);
            userName = (TextView)view.findViewById(R.id.user_name);
            time = (TextView)view.findViewById(R.id.time);
            message = (TextView)view.findViewById(R.id.message);
        }
    }
}
