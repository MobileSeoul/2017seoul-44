package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.activities.Category_detail.Category_detail;

/**
 * Created by KimDongGyu on 2017-10-23.
 */

public class Category extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.f_category, container, false);
        ImageView imageViewTourist = (ImageView)view.findViewById(R.id.category_tourist);
        ImageView imageViewCultural = (ImageView)view.findViewById(R.id.category_cultural);
        ImageView imageViewEvent = (ImageView)view.findViewById(R.id.category_event);
        ImageView imageViewCourse = (ImageView)view.findViewById(R.id.category_course);
        ImageView imageViewLeisure = (ImageView)view.findViewById(R.id.category_leisure);
        ImageView imageViewAccommodation = (ImageView)view.findViewById(R.id.category_accommodation);
        ImageView imageViewShopping = (ImageView)view.findViewById(R.id.category_shopping);
        ImageView imageViewRestaurant = (ImageView)view.findViewById(R.id.category_restaurant);
        Glide.with(this).load(R.drawable.bg_tourist).into(imageViewTourist);
        Glide.with(this).load(R.drawable.bg_cultural).into(imageViewCultural);
        Glide.with(this).load(R.drawable.bg_event).into(imageViewEvent);
        Glide.with(this).load(R.drawable.bg_course).into(imageViewCourse);
        Glide.with(this).load(R.drawable.bg_leisure).into(imageViewLeisure);
        Glide.with(this).load(R.drawable.bg_accommodation).into(imageViewAccommodation);
        Glide.with(this).load(R.drawable.bg_shopping).into(imageViewShopping);
        Glide.with(this).load(R.drawable.bg_restaurant).into(imageViewRestaurant);

        imageViewTourist.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Tourist");
                startActivity(intent);
            }
        });

        imageViewCultural.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Culture");
                startActivity(intent);
            }
        });

        imageViewEvent.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Events");
                startActivity(intent);
            }
        });

        imageViewCourse.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Course");
                startActivity(intent);
            }
        });

        imageViewLeisure.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Leisure");
                startActivity(intent);
            }
        });

        imageViewAccommodation.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Accommodation");
                startActivity(intent);
            }
        });

        imageViewShopping.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Shopping");
                startActivity(intent);
            }
        });

        imageViewRestaurant.setOnClickListener(new Button.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(getContext(), Category_detail.class);
                intent.putExtra("key","Restaurant");
                startActivity(intent);
            }
        });


        return view;
    }
}
