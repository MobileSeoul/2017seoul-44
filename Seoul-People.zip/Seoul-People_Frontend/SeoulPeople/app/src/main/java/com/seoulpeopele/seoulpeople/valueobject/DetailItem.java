package com.seoulpeopele.seoulpeople.valueobject;

/**
 * Created by dsm2016 on 2017-10-25.
 */

public class DetailItem {

    private String detail_title;

    public String getDetail_title() {
        return detail_title;
    }

    public void setDetail_title(String detail_title) {
        this.detail_title = detail_title;
    }

    public String getDetail_address() {
        return detail_address;
    }

    public void setDetail_address(String detail_address) {
        this.detail_address = detail_address;
    }

    public String getDetail_category() {
        return detail_category;
    }

    public void setDetail_category(String detail_category) {
        this.detail_category = detail_category;
    }

    public int getDetail_content_id() {
        return detail_content_id;
    }

    public void setDetail_content_id(int detail_content_id) {
        this.detail_content_id = detail_content_id;
    }

    public int getDetail_cotent_type_id() {
        return detail_cotent_type_id;
    }

    public void setDetail_cotent_type_id(int detail_cotent_type_id) {
        this.detail_cotent_type_id = detail_cotent_type_id;
    }

    public String getDetail_image() {
        return detail_image;
    }

    public void setDetail_image(String detail_image) {
        this.detail_image = detail_image;
    }

    public int getDetail_wish_count() {
        return detail_wish_count;
    }

    public void setDetail_wish_count(int detail_wish_count) {
        this.detail_wish_count = detail_wish_count;
    }

    public boolean isDetail_wished() {
        return detail_wished;
    }

    public void setDetail_wished(boolean detail_wished) {
        this.detail_wished = detail_wished;
    }

    private String detail_address;
    private String detail_category;
    private int detail_content_id;
    private int detail_cotent_type_id;
    private String detail_image;
    private int detail_wish_count;
    private boolean detail_wished;


}
