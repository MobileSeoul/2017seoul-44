package com.seoulpeopele.seoulpeople.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.activities.AddressBook;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.AddressBookItem;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by dsm2016 on 2017-10-25.
 */

public class AddressBookAdapter extends RecyclerView.Adapter<AddressBookAdapter.ViewHolder> {
    private APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);
    private JsonArray mDataset;
    private String mAccessToken;

    public AddressBookAdapter(JsonArray dataset, String accessToken){
        this.mDataset = dataset;
        this.mAccessToken = accessToken;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView user_name;
        public TextView user_phone;
        public TextView user_email;

        public ViewHolder(View view) {
            super(view);
            user_name = (TextView)view.findViewById(R.id.user_name);
            user_phone = (TextView)view.findViewById(R.id.user_phone);
            user_email = (TextView)view.findViewById(R.id.user_email);
        }
    }

    @Override
    public AddressBookAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.r_address_book, parent, false);
        return new AddressBookAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final AddressBookAdapter.ViewHolder holder, final int position) {
        apiInterface.getUserInfo(mDataset.get(position).getAsString(), mAccessToken).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                holder.user_name.setText(response.body().get("name").getAsString());
                holder.user_phone.setText(response.body().get("phone").getAsString());
                holder.user_email.setText(response.body().get("email").getAsString());
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
