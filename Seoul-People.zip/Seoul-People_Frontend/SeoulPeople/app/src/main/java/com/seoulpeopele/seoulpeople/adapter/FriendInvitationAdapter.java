package com.seoulpeopele.seoulpeople.adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.util.ArrayMap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by geni on 2017. 10. 26..
 */

public class FriendInvitationAdapter extends RecyclerView.Adapter<FriendInvitationAdapter.ViewHolder> {
    private JsonArray mDataSet;
    private APIInterface apiInterface;
    private String mAccessToken;
    private Context mContext;
    private JsonArray checkList = new JsonArray();

    public FriendInvitationAdapter(JsonArray dataSet, String accessToken, Context context){
        this.mDataSet = dataSet;
        this.mAccessToken = accessToken;
        this.mContext = context;
    }

    @Override
    public FriendInvitationAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.i_friend_invitation, parent, false);
        return new FriendInvitationAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final FriendInvitationAdapter.ViewHolder holder, final int position) {
        apiInterface = APIClient.getClient().create(APIInterface.class);
        apiInterface.getUserInfo(mDataSet.get(position).getAsString(), mAccessToken).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, final Response<JsonObject> response) {
                Log.d("asdf", holder.userName+"");
                holder.userName.setText(response.body().get("name").getAsString());
                holder.userPhone.setText(response.body().get("phone").getAsString());
                holder.userEmail.setText(response.body().get("email").getAsString());
                holder.addFriendBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(holder.checkBox.isChecked()){
                            holder.checkBox.setChecked(false);
                            JsonObject obj = new JsonObject();
                            obj.addProperty("id", response.body().get("id").getAsString());
                            obj.addProperty("check", false);
                            obj.addProperty("token", mAccessToken);
                            checkList.add(obj);
                            holder.addFriendBtn.setBackgroundResource(R.drawable.ic_unchoice);
                            Log.d("checkbox", "check false");
                        } else {
                            holder.checkBox.setChecked(true);
                            JsonObject obj = new JsonObject();
                            obj.addProperty("id", response.body().get("id").getAsString());
                            obj.addProperty("check", true);
                            obj.addProperty("token", mAccessToken);
                            checkList.add(obj);
                            holder.addFriendBtn.setBackgroundResource(R.drawable.ic_choice);
                            Log.d("checkbox", "check true");
                        }
                    }
                });
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        private TextView userName, userPhone, userEmail;
        private Button addFriendBtn;
        private CheckBox checkBox;

        public ViewHolder(View view){
            super(view);
            userName = (TextView)view.findViewById(R.id.user_name);
            userPhone = (TextView)view.findViewById(R.id.user_phone);
            userEmail = (TextView)view.findViewById(R.id.user_email);
            addFriendBtn = (Button)view.findViewById(R.id.add_friend);
            checkBox = (CheckBox)view.findViewById(R.id.checkbox);
        }
    }

    public JsonArray getCheckList(){
        return checkList;
    }
}
