package com.seoulpeopele.seoulpeople.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.activities.ActiveJourney;
import com.seoulpeopele.seoulpeople.valueobject.ActiveJourneyItem;
import com.seoulpeopele.seoulpeople.valueobject.DetailItem;

import java.util.ArrayList;

/**
 * Created by dsm2016 on 2017-10-25.
 */

public class ActiveJourneyAdapter extends RecyclerView.Adapter<ActiveJourneyAdapter.ViewHolder> {
    private ArrayList<ActiveJourneyItem> mDataset;
    public ActiveJourneyAdapter(ArrayList<ActiveJourneyItem> myDataset) {
        this.mDataset = myDataset;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView chat_title;
        public TextView chat_preview;
        public TextView chat_time;
        public TextView chat_count;

        public ViewHolder(View view) {
            super(view);
            chat_title = (TextView)view.findViewById(R.id.active_journey_title);
            chat_preview = (TextView)view.findViewById(R.id.active_journey_preview);
            chat_time = (TextView)view.findViewById(R.id.time);
            chat_count = (TextView)view.findViewById(R.id.active_journey_chat_count);
        }
    }

    public void setData(ActiveJourneyItem[] datas){
        ArrayList<ActiveJourneyItem> arrayListDatas = new ArrayList<>();
        for(ActiveJourneyItem data : datas){
            arrayListDatas.add(data);
        }
        mDataset = arrayListDatas;
    }

    @Override
    public ActiveJourneyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.r_active_journey, parent, false);
        ActiveJourneyAdapter.ViewHolder vh = new ActiveJourneyAdapter.ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ActiveJourneyAdapter.ViewHolder holder, final int position) {
        holder.chat_title.setText(mDataset.get(position).getChat_title());
        holder.chat_preview.setText(mDataset.get(position).getChat_preview());
        holder.chat_time.setText(mDataset.get(position).getChat_time());
        holder.chat_count.setText(mDataset.get(position).getChat_count()+"");
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
