package com.seoulpeopele.seoulpeople.activities;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.seoulpeopele.seoulpeople.R;

/**
 * Created by dsm2016 on 2017-10-23.
 */

public class Wishlist_Recycler extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.r_wishlist);

        ImageView imageView = (ImageView)findViewById(R.id.wish_back_image);
        imageView.setClipToOutline(true);

    }

}
