package com.seoulpeopele.seoulpeople.support.network;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.support.item.SignInBody;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by geni on 2017. 10. 19..
 */

public interface APIInterface {
    //SignUp
    @FormUrlEncoded
    @POST("/signup")
    Call<Void> doSignUp(@Field("id") String id,
                        @Field("pw") String pwd,
                        @Field("registration_id") String registration_id,
                        @Field("email") String email,
                        @Field("phone") String phone,
                        @Field("name") String name);

    @FormUrlEncoded
    @POST("/signup/facebook")
    Call<Void> doFacebookSignUp(@Field("fb_id") String facebookId,
                                @Field("access_token") String accessToken,
                                @Field("registration_id") String registrationId,
                                @Field("phone") String phone);

    @GET("/certify/email")
    Call<Void> getEmailCertifyCode(@Query("email") String email);

    @GET("/tour-list/main")
    Call<JsonObject> getMainTourList(@Header("Authorization") String Authorization,
                                     @Query("festival_len") int festival_len,
                                     @Query("popular_len") int popular_len,
                                     @Query("monthly_len") int monthly_len);

    @FormUrlEncoded
    @POST("/certify/email")
    Call<Void> doEmailCertify(@Field("email") String email,
                              @Field("code") int code);

    @FormUrlEncoded
    @POST("/check/email")
    Call<Void> doCheckEmail(@Field("email") String email);

    //SignIn
    @Headers({"Content-Type: application/json"})
    @POST("/auth")
    Call<JsonObject> doSignIn(@Body SignInBody signInBody);

    //WishList
    @GET("/wish-list")
    Call<JsonArray> getWishList(@Header("Authorization") String Authorization);

    //TourList
    @GET("/tour-detail")
    Call<JsonObject> getTourDetail(@Query("content_id") int content_id,
                                   @Header("Authorization") String Authorization);

    @GET("/tour-list/categorized")
    Call<JsonArray> getTourListCategorized(@Header("Authorization") String Authorization,
                                           @Query("category") String category,
                                           @Query("sort_type") int sort_type,
                                           @Query("page") int page);

    @GET("/tour-list/searched")
    Call<JsonArray> getTourListSearched(@Header("Authorization") String Authorization,
                                        @Query("keyword") String keyword,
                                        @Query("sort_type") int sort_type,
                                        @Query("page") int page);

    //Frined
    @GET("/friend")
    Call<JsonArray> getFriendList(@Header("Authorization") String Authorization);

    @FormUrlEncoded
    @POST("friend-invite")
    Call<Void> sendFriendRequest(@Field("receiver_id") String receiverId,
                                 @Header("Authorization") String Authorization);

    //FriendRequest
    @GET("/friend-invite/received")
    Call<JsonArray> getReceivedList(@Header("Authorization") String Authorization);

    @FormUrlEncoded
    @POST("/friend-invite/received")
    Call<Void> receiveRequest(@Field("requester_id") String requester_id,
                             @Header("Authorization") String Authorization);

    @FormUrlEncoded
    @DELETE("/friend-invite/received")
    Call<Void> rejectRequest(@Field("requester_id") String requester_id,
                             @Header("Authorization") String Authorization);

    //UserSearch
    @GET("/user-search")
    Call<JsonObject> getUserInfo(@Query("id") String id,
                                 @Header("Authorization") String Authorization);

    //MyPage
    @GET("/mypage")
    Call<JsonObject> getMyPageInfo(@Header("Authorization") String Authorization);

    //Chatting
    @FormUrlEncoded
    @POST("/chat")
    Call<JsonObject> makeChat(@Field("title") String title,
                              @Header("Authorization") String Authorization);

    @GET("/chat")
    Call<JsonArray> getChatList(@Header("Authorization") String Authorization);

    @FormUrlEncoded
    @POST("/chat/invite")
    Call<Void> inviteFriend(@Field("topic") String topic,
                            @Field("target_id")String tragetId,
                            @Header("Authorization") String Authorization);

    @FormUrlEncoded
    @POST("/wish-list")
    Call<Void> addWish(@Field("content_id") int contentId,
                       @Header("Authorization") String Authorization);

}
