package com.seoulpeopele.seoulpeople.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.activities.Chatting;
import com.seoulpeopele.seoulpeople.valueobject.ChattingItem;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmResults;

/**
 * Created by geni on 2017. 10. 29..
 */

public class ChatRoomAdapter extends RecyclerView.Adapter<ChatRoomAdapter.ViewHolder> {
    private RealmResults<ChattingItem> mDataSet;
    private Activity mActivity;
    private String name;
    private FirebaseDatabase fdb = FirebaseDatabase.getInstance();
    private DatabaseReference dbReference = fdb.getReference();

    public ChatRoomAdapter(RealmResults<ChattingItem> dataSet, Activity activity, String name){
        this.mDataSet = dataSet;
        this.mActivity = activity;
        this.name = name;
    }

    @Override
    public ChatRoomAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.r_active_journey, parent, false);
        return new ChatRoomAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ChatRoomAdapter.ViewHolder holder, final int position) {
        holder.title.setText(mDataSet.get(position).getChatName());
        if(mDataSet.get(position).getChatItems().size() != 0){
            holder.preview.setText(mDataSet.get(position).getChatItems().get(mDataSet.get(position).getChatItems().size() - 1).getMessage());
            holder.time.setText(mDataSet.get(position).getChatItems().get(mDataSet.get(position).getChatItems().size() - 1).getTime());
        } else {
            holder.preview.setText("");
            holder.time.setText("");
        }
        dbReference.child(mDataSet.get(position).getTopic()).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Log.d("child count", dataSnapshot.getChildrenCount()+"");
                if(mDataSet.get(position).getChatItems().size() != 0){
                    String newCount = (dataSnapshot.getChildrenCount() - mDataSet.get(position).getChatItems().size())+"";
                    holder.chatCount.setText(newCount);
                } else {
                    holder.chatCount.setText("");
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        holder.area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mActivity.getApplicationContext(), Chatting.class);
                intent.putExtra("topic", mDataSet.get(position).getTopic());
                intent.putExtra("title", mDataSet.get(position).getChatName());
                intent.putExtra("name", name);
                mActivity.startActivity(intent);
                mActivity.finish();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView chatCount;
        private TextView title;
        private TextView preview;
        private TextView time;
        private LinearLayout area;

        public ViewHolder(View view){
            super(view);
            chatCount = (TextView)view.findViewById(R.id.chat_count);
            title = (TextView)view.findViewById(R.id.title);
            preview = (TextView)view.findViewById(R.id.preview);
            time = (TextView)view.findViewById(R.id.time);
            area = (LinearLayout)view.findViewById(R.id.area);
        }
    }
}
