package com.seoulpeopele.seoulpeople.activities;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements ViewPager.OnPageChangeListener, NavigationView.OnNavigationItemSelectedListener {

    private APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);
    private Realm mRealm;

    private BottomNavigationView bottomnavigationView;
    private ViewPager viewPager;

    private Button buttonSearch;
    private Button buttonFilter;
    private Button buttonMenu;

    private MainFragment mainFragment = new MainFragment();
    private Category category = new Category();
    private MyPage my_page = new MyPage();
    private Option option = new Option();
    private TextView name, email, phonenum;
    private ImageView profileimg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        NavigationView navigationView = (NavigationView) findViewById(R.id.main_nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header = navigationView.getHeaderView(0);
/*View        view=navigationView.inflateHeaderView(R.layout.nav_header_main);*/
        name = (TextView)header.findViewById(R.id.navigation_header_nameView);
        email = (TextView)header.findViewById(R.id.navigation_header_emailView);
        phonenum = (TextView)header.findViewById(R.id.navigation_header_phoneNumberView);

        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                apiInterface.getMyPageInfo(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        Log.d("xxx",response.body().get("email").toString().replaceAll("\"", ""));
                        email.setText(response.body().get("email").toString().replaceAll("\"", ""));
                        name.setText(response.body().get("name").toString().replaceAll("\"", ""));
                        phonenum.setText(response.body().get("phone").toString().replaceAll("\"", ""));
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });



        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.main_drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        buttonMenu = (Button) findViewById(R.id.main_menu);
        buttonMenu.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });

        buttonSearch = (Button) findViewById(R.id.main_search);
        buttonSearch.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentfilter = new Intent(MainActivity.this, Search.class);
                startActivity(intentfilter);
            }
        });

        buttonFilter = (Button) findViewById(R.id.main_filter);
        buttonFilter.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentfilter = new Intent(MainActivity.this, FilterActivity.class);
                startActivity(intentfilter);
            }
        });

        viewPager = (ViewPager) findViewById(R.id.main_viewpager);
        viewPager.addOnPageChangeListener(this);
        bottomnavigationView = (BottomNavigationView) findViewById(R.id.main_navigation);
        bottomnavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        viewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public android.support.v4.app.Fragment getItem(int position) {
                switch (position) {
                    case 0:
                        return mainFragment;
                    case 1:
                        return category;
                    case 2:
                        return my_page;
                    case 3:
                        return option;
                }
                return null;
            }

            @Override
            public int getCount() {
                return 4;
            }
        });
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            viewPager.setCurrentItem(item.getOrder());
            switch (item.getItemId()) {
                case R.id.action_one:
                    viewPager.setCurrentItem(0);
                    return true;
                case R.id.action_two:
                    viewPager.setCurrentItem(1);
                    return true;
                case R.id.action_three:
                    viewPager.setCurrentItem(2);
                    return true;
                case R.id.action_four:
                    viewPager.setCurrentItem(3);
                    return true;
            }
            return false;
        }
    };

    @Override
    public void onBackPressed() {
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.main_drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            // 백스택이 존재할 떄까지
            if (fm.getBackStackEntryCount() > 0)
            {
                fm.popBackStack();
                ft.commit();
            }
            // 백스택이 없는 경우
            else
            {
                super.onBackPressed();
            }
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        android.app.Fragment fragment = null;
        String title = getString(R.string.app_name);

        // 네비게이션 뷰 조작
        switch (id) {
            case R.id.nav_sub_menu_item01:
                // 위시리스트

                break;
            case R.id.nav_sub_menu_item02:
                // 친구 목록
                startActivity(new Intent(getApplicationContext(), AddressBook.class));
                break;
            case R.id.nav_sub_menu_item03:
                // 최근여행지

                break;
            case R.id.nav_sub_menu_item04:
                // 활성화된 여행
                startActivity(new Intent(getApplicationContext(), ActiveJourney.class));
                break;
            default:
                Toast.makeText(getApplicationContext(), "비정상적인 접근입니다.", Toast.LENGTH_LONG).show();
                break;
        }

            if (fragment != null) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.addToBackStack("sidemenufragment").add(R.id.main_container, fragment);
                ft.commit();
            }

            if (getSupportActionBar() != null) {
                ((TextView) findViewById(R.id.toolbar_title)).setText(title);
            }


            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.main_drawer_layout);
            drawer.closeDrawer(GravityCompat.START);

            return true;
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        bottomnavigationView.getMenu().getItem(position).setChecked(true);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

}