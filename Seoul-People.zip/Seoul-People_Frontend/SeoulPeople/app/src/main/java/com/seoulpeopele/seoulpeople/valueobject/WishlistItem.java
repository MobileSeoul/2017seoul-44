package com.seoulpeopele.seoulpeople.valueobject;

/**
 * Created by dsm2016 on 2017-10-23.
 */

public class WishlistItem {
    private String place_name;
    private String place_address;
    private String wish_back_image;

    public String getPlace_name() {
        return place_name;
    }

    public void setPlace_name(String place_name) {
        this.place_name = place_name;
    }

    public String getPlace_address() {
        return place_address;
    }

    public void setPlace_address(String place_address) {
        this.place_address = place_address;
    }

    public String getWish_back_image() {
        return wish_back_image;
    }

    public void setWish_back_image(String wish_back_image) {
        this.wish_back_image = wish_back_image;
    }
}
