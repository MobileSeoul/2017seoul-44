package com.seoulpeopele.seoulpeople.support.item;

import com.google.gson.annotations.SerializedName;

/**
 * Created by geni on 2017. 10. 25..
 */

public class SignInBody {
    @SerializedName("id")
    private String id;
    @SerializedName("pw")
    private String pw;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }
}
