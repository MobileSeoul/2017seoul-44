package com.seoulpeopele.seoulpeople.valueobject;

/**
 * Created by dsm2016 on 2017-10-26.
 */

public class RecentDestinationItem {

    private String visitor;
    private int like;
    private String recent_title;
    private String recent_address;

    public String getVisitor() {
        return visitor;
    }

    public void setVisitor(String visitor) {
        this.visitor = visitor;
    }

    public int getLike() {
        return like;
    }

    public void setLike(int like) {
        this.like = like;
    }

    public String getRecent_title() {
        return recent_title;
    }

    public void setRecent_title(String recent_title) {
        this.recent_title = recent_title;
    }

    public String getRecent_address() {
        return recent_address;
    }

    public void setRecent_address(String recent_address) {
        this.recent_address = recent_address;
    }
}
