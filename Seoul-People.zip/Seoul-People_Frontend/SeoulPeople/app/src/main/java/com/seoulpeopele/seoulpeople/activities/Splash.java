package com.seoulpeopele.seoulpeople.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.item.SignInBody;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Splash extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    private Realm mRealm;
    private APIInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_splash);

        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        judge();
    }

    public void judge(){
        sharedPreferences = getSharedPreferences("SharedPreference", MODE_PRIVATE);
        if(sharedPreferences.getBoolean("isFirstRun", true)){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isFirstRun", false);
            editor.apply();
            startActivity(new Intent(getApplicationContext(), Accounts.class));
            finish();
        } else if(sharedPreferences.getBoolean("isSignIn", false)){
            Log.d("what", "the");
            mRealm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    final UserCertifyItem certifyItem = realm.where(UserCertifyItem.class).findFirst();
                    SignInBody body = new SignInBody();
                    body.setId(certifyItem.getUserId());
                    body.setPw(certifyItem.getUserPw());
                    apiInterface.doSignIn(body).enqueue(new retrofit2.Callback<JsonObject>() {
                        @Override
                        public void onResponse(Call<JsonObject> call, final Response<JsonObject> response) {
                            mRealm.executeTransaction(new Realm.Transaction() {
                                @Override
                                public void execute(Realm realm) {
                                    certifyItem.setAccessToken(response.body().get("access_token").getAsString());
                                }
                            });
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            finish();
                        }

                        @Override
                        public void onFailure(Call<JsonObject> call, Throwable t) {
                            t.printStackTrace();
                        }
                    });
                }
            });
        }
    }
}
