package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.ChattingItem;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateChatting extends AppCompatActivity {
    private EditText inputChatName;
    private Button createBtn;
    private APIInterface apiInterface;
    private Realm mRealm;
    private Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_create_chatting);
        inputChatName = (EditText)findViewById(R.id.create_chatting_name);
        createBtn = (Button)findViewById(R.id.btn_create);

        apiInterface = APIClient.getClient().create(APIInterface.class);
        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();
        mIntent = getIntent();

        createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mRealm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(final Realm realm) {
                       apiInterface.makeChat(
                               inputChatName.getText().toString(),
                               "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                       ).enqueue(new retrofit2.Callback<JsonObject>() {
                           @Override
                           public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                               Intent intent = new Intent(getApplicationContext(), FriendInvitation.class);
                               intent.putExtra("topic", response.body().get("topic").getAsString());
                               intent.putExtra("title", inputChatName.getText().toString());
                               intent.putExtra("name", mIntent.getStringExtra("name"));
                               realm.beginTransaction();
                               ChattingItem item = realm.createObject(ChattingItem.class, response.body().get("topic").getAsString());
                               item.setChatName(inputChatName.getText().toString());
                               realm.commitTransaction();
                               startActivity(intent);
                               finish();
                           }

                           @Override
                           public void onFailure(Call<JsonObject> call, Throwable t) {
                                t.printStackTrace();
                           }
                       });
                    }
                });
            }
        });
    }

    public void onBackBtnClicked(View view){
        finish();
    }
}
