package com.seoulpeopele.seoulpeople.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.DetailAdapter;
import com.seoulpeopele.seoulpeople.adapter.RecentDestinationAdapter;
import com.seoulpeopele.seoulpeople.valueobject.DetailItem;
import com.seoulpeopele.seoulpeople.valueobject.RecentDestinationItem;

import java.util.ArrayList;

public class RecentDestination extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter myAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<RecentDestinationItem> Dataset = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_recent_destination);

        mRecyclerView = (RecyclerView)findViewById(R.id.recycler_recent_destination);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        for(int i = 0; i < 5; i++) {
            RecentDestinationItem recentDestinationItem = new RecentDestinationItem();
            recentDestinationItem.setVisitor("50" + " 명이 방문");
            recentDestinationItem.setLike(50);
            recentDestinationItem.setRecent_title("페인터즈 히어로");
            recentDestinationItem.setRecent_address("서울특별시 중구 돈화문로 13");

            Dataset.add(recentDestinationItem);
        }

        myAdapter = new RecentDestinationAdapter(Dataset);
        mRecyclerView.setAdapter(myAdapter);
    }
}
