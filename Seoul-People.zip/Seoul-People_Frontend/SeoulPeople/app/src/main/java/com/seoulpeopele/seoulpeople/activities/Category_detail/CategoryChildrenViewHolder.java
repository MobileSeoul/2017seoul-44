package com.seoulpeopele.seoulpeople.activities.Category_detail;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.activities.Detail;
import com.thoughtbot.expandablerecyclerview.viewholders.ChildViewHolder;

public class CategoryChildrenViewHolder extends ChildViewHolder {

  private TextView childTextView;
  private Button childButton;
  private String childCode;
  private String category_key;

  public CategoryChildrenViewHolder(final View itemView) {
    super(itemView);
    childTextView = (TextView) itemView.findViewById(R.id.subitem_name);
    childButton = (Button) itemView.findViewById(R.id.filter_detail_subitem_btn);

    childButton.setOnClickListener(new Button.OnClickListener() {
      @Override
      public void onClick(View view) {
        Intent intent = new Intent(view.getContext(), Detail.class);
        intent.putExtra("category", childCode);
        intent.putExtra("category_key", category_key);
        view.getContext().startActivity(intent);
      }
    }) ;
  }

  public void setChildrenName(String name) {
    childTextView.setText(name);
  }

  public void setChildCode(String childCode) {
    this.childCode = childCode;
  }

  public void setCategory_key(String category_key) {
    this.category_key = category_key;
  }
}
