package com.seoulpeopele.seoulpeople.valueobject;

/**
 * Created by geni on 2017. 10. 29..
 */

public class FriendInvitationItem {
    private String userName;
    private String userPhone;
    private String userEmail;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
