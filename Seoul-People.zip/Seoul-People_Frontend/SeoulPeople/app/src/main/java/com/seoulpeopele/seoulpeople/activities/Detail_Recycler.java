package com.seoulpeopele.seoulpeople.activities;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.seoulpeopele.seoulpeople.R;

public class Detail_Recycler extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.r_detail);

        ImageView imageView = (ImageView)findViewById(R.id.detail_back_image);
        imageView.setClipToOutline(true);
    }
}
