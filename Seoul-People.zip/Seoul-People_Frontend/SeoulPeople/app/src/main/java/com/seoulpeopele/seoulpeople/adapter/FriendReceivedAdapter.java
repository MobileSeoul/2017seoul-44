package com.seoulpeopele.seoulpeople.adapter;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by geni on 2017. 10. 26..
 */

public class FriendReceivedAdapter extends RecyclerView.Adapter<FriendReceivedAdapter.ViewHolder> {
    private JsonArray mDataSet;
    private APIInterface apiInterface;
    private String mAccessToken;

    public FriendReceivedAdapter(JsonArray dataSet, String accessToken){
        this.mDataSet = dataSet;
        this.mAccessToken = accessToken;
    }

    @Override
    public FriendReceivedAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.i_friend_receive, parent, false);
        return new FriendReceivedAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final FriendReceivedAdapter.ViewHolder holder, final int position) {
        Log.d("id", mDataSet.get(position).getAsString());
        apiInterface = APIClient.getClient().create(APIInterface.class);
        apiInterface.getUserInfo(mDataSet.get(position).getAsString(), mAccessToken).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                holder.userName.setText(response.body().get("name").getAsString());
                holder.userPhone.setText(response.body().get("phone").getAsString());
                holder.userEmail.setText(response.body().get("email").getAsString());

                holder.receiveBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        apiInterface.receiveRequest(mDataSet.get(position).getAsString(), mAccessToken).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                if(response.code() == 201){
                                    holder.area.setVisibility(View.GONE);
                                }
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                t.printStackTrace();
                            }
                        });
                    }
                });

                holder.rejectBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        apiInterface.rejectRequest(mDataSet.get(position).getAsString(), mAccessToken).enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                if(response.code() == 200){
                                    holder.area.setVisibility(View.GONE);
                                }
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {

                            }
                        });
                    }
                });
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView userName, userPhone, userEmail;
        private Button receiveBtn, rejectBtn;
        private LinearLayout area;

        public ViewHolder(View view){
            super(view);
            userName = (TextView)view.findViewById(R.id.user_name);
            userPhone = (TextView)view.findViewById(R.id.user_phone);
            userEmail = (TextView)view.findViewById(R.id.user_email);
            receiveBtn = (Button)view.findViewById(R.id.btn_receive);
            rejectBtn = (Button)view.findViewById(R.id.btn_reject);
            area = (LinearLayout)view.findViewById(R.id.friend_request_area);
        }
    }
}
