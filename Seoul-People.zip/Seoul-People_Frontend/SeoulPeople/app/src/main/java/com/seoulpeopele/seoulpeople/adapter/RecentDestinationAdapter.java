package com.seoulpeopele.seoulpeople.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.valueobject.RecentDestinationItem;

import java.util.ArrayList;

/**
 * Created by dsm2016 on 2017-10-26.
 */

public class RecentDestinationAdapter extends RecyclerView.Adapter<RecentDestinationAdapter.ViewHolder>{
    private ArrayList<RecentDestinationItem> mDataset;
    public RecentDestinationAdapter(ArrayList<RecentDestinationItem> myDataset){ this.mDataset=myDataset; }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public Button recent_visitor;
        public Button recent_like;
        public TextView recent_title;
        public TextView recent_address;

        public ViewHolder(View view) {
            super(view);
            recent_visitor = (Button)view.findViewById(R.id.btn_recent_visitor);
            recent_like = (Button)view.findViewById(R.id.btn_recent_like);
            recent_title = (TextView)view.findViewById(R.id.recent_title);
            recent_address = (TextView)view.findViewById(R.id.recent_address);
        }
    }

    public void setData(RecentDestinationItem[] datas){
        ArrayList<RecentDestinationItem>arrayListDatas=new ArrayList<>();
        for(RecentDestinationItem data:datas){
            arrayListDatas.add(data);
        }
        mDataset=arrayListDatas;
    }

    @Override
    public RecentDestinationAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.r_recent_destination, parent, false);
        RecentDestinationAdapter.ViewHolder vh = new RecentDestinationAdapter.ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(RecentDestinationAdapter.ViewHolder holder,final int position){
        holder.recent_visitor.setText(mDataset.get(position).getVisitor());
        holder.recent_like.setText(mDataset.get(position).getLike()+"");
        holder.recent_title.setText(mDataset.get(position).getRecent_title());
        holder.recent_address.setText(mDataset.get(position).getRecent_address());
    }

    @Override
    public int getItemCount(){ return mDataset.size(); }
}
