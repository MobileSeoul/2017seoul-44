package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by KimDongGyu on 2017-10-23.
 */

public class MyPage extends Fragment {
    private APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);
    private Realm mRealm;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        ViewGroup viewGroup = (ViewGroup)inflater.inflate(R.layout.f_my_page, container, false);
        mRealm.init(getContext());
        mRealm = Realm.getDefaultInstance();

        ImageView user_img = (ImageView)viewGroup.findViewById(R.id.my_page_user_img);
        final TextView userName = (TextView)viewGroup.findViewById(R.id.user_name);
        final TextView userEmail = (TextView)viewGroup.findViewById(R.id.user_email);
        final TextView userPhone = (TextView)viewGroup.findViewById(R.id.user_phone);
        LinearLayout friendRequest = (LinearLayout)viewGroup.findViewById(R.id.friend_request);

        friendRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), FriendRequest.class));
            }
        });

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                apiInterface.getMyPageInfo(
                        "JWT " + realm.where(UserCertifyItem.class).findFirst().getAccessToken()
                ).enqueue(new retrofit2.Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        Log.d("xxx",response.body().get("email").toString().replaceAll("\"", ""));
                        userEmail.setText(response.body().get("email").toString().replaceAll("\"", ""));
                        userName.setText(response.body().get("name").toString().replaceAll("\"", ""));
                        userPhone.setText(response.body().get("phone").toString().replaceAll("\"", ""));
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });

        return viewGroup;
    }
}
