package com.seoulpeopele.seoulpeople.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.ChatLogAdapter;
import com.seoulpeopele.seoulpeople.valueobject.ChatItem;
import com.seoulpeopele.seoulpeople.valueobject.ChattingItem;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import io.realm.Realm;
import io.realm.RealmList;

/**
 * Created by geni on 2017. 10. 28..
 */

public class Chatting extends AppCompatActivity {
    private FirebaseDatabase fdb = FirebaseDatabase.getInstance();
    private DatabaseReference dbReference = fdb.getReference();
    private Intent mIntent;
    private Realm mRealm;
    private ArrayList<ChatItem> chatItems = new ArrayList<>();

    private Button sendBtn;
    private EditText inputMessage;
    private RecyclerView chatLogsView;
    private TextView chattingName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_chatting);
        mIntent = getIntent();
        mRealm.init(getApplicationContext());
        mRealm = Realm.getDefaultInstance();

        sendBtn = (Button)findViewById(R.id.btn_send);
        inputMessage = (EditText)findViewById(R.id.edit_message);
        chatLogsView = (RecyclerView)findViewById(R.id.chatLogs);
        chattingName = (TextView)findViewById(R.id.chatting_name);

        chattingName.setText(mIntent.getStringExtra("title"));

        //POST CHAT
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                String time;
                if(calendar.get(Calendar.HOUR_OF_DAY) >= 12){
                    time = "오후 " + calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE);
                } else {
                    time = "오전 " + calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE);
                }
                ChatItem item = new ChatItem(mIntent.getStringExtra("name"), time, inputMessage.getText().toString());
                dbReference.child(mIntent.getStringExtra("topic"))
                        .push()
                        .setValue(item);
                inputMessage.setText("");
            }
        });

        //GET CHAT
        dbReference.child(mIntent.getStringExtra("topic")).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                final ChatItem chatItem = dataSnapshot.getValue(ChatItem.class);
                Log.d("item", chatItem.getMessage());
                ChatItem item = new ChatItem(chatItem.getUserName(), chatItem.getTime(), chatItem.getMessage());
                chatItems.add(item);
                chatLogsView.setAdapter(new ChatLogAdapter(chatItems));
                chatLogsView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {}

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {}

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });
    }

    public void onBackBtnClicked(View view){
        startActivity(new Intent(getApplicationContext(), ActiveJourney.class));
        finish();
    }
}
