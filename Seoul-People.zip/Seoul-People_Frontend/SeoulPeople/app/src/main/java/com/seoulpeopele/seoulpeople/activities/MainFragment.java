package com.seoulpeopele.seoulpeople.activities;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.rd.PageIndicatorView;
import com.rd.animation.type.AnimationType;
import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.MainFestivalAdapter;
import com.seoulpeopele.seoulpeople.adapter.MainMonthlyAdapter;
import com.seoulpeopele.seoulpeople.adapter.MainPopularAdapter;
import com.seoulpeopele.seoulpeople.support.item.UserCertifyItem;
import com.seoulpeopele.seoulpeople.support.network.APIClient;
import com.seoulpeopele.seoulpeople.support.network.APIInterface;
import com.seoulpeopele.seoulpeople.valueobject.MainFestivalItem;
import com.seoulpeopele.seoulpeople.valueobject.MainMonthlyItem;
import com.seoulpeopele.seoulpeople.valueobject.MainPopularItem;

import java.util.ArrayList;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by KimDongGyu on 2017-10-23.
 */

public class MainFragment extends Fragment {

    private APIInterface apiInterface;
    private Realm mRealm;
    private ArrayList<MainFestivalItem> arrayListF = new ArrayList<>();
    private ArrayList<MainMonthlyItem> arrayListM = new ArrayList<>();
    private ArrayList<MainPopularItem> arrayListP = new ArrayList<>();
    private ViewPager viewPagerFestival;
    private PageIndicatorView pageIndicatorView;
    private ViewPager viewPagerMonthly;
    private ViewPager viewPagerPopular;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        ViewGroup viewGroup = (ViewGroup)inflater.inflate(R.layout.f_main, container, false);

        viewPagerFestival = (ViewPager) viewGroup.findViewById(R.id.main_first_container_viewpager);
        pageIndicatorView = (PageIndicatorView) viewGroup.findViewById(R.id.main_first_container);
        viewPagerMonthly = (ViewPager) viewGroup.findViewById(R.id.main_viewpager_monthly);
        viewPagerPopular = (ViewPager) viewGroup.findViewById(R.id.main_viewpager_popular);

        //festival_viewpager
        apiInterface = APIClient.getClient().create(APIInterface.class);
        mRealm.init(getContext());
        mRealm = Realm.getDefaultInstance();
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                UserCertifyItem certifyItem = realm.where(UserCertifyItem.class).findFirst();
                Log.d("token", certifyItem.getAccessToken());
                apiInterface.getMainTourList("JWT " + certifyItem.getAccessToken(),5, 5, 5).enqueue(new retrofit2.Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        if (response.code() == 200) {
                            JsonArray jsonArrayF = response.body().get("festival").getAsJsonArray();
                            JsonArray jsonArrayM = response.body().get("monthly").getAsJsonArray();
                            JsonArray jsonArrayP = response.body().get("popular").getAsJsonArray();
                            for (int i = 0; i < jsonArrayM.size(); i++) {
                                MainFestivalItem mainFestivalItem = new MainFestivalItem();
                                MainMonthlyItem mainMonthlyItem = new MainMonthlyItem();
                                MainPopularItem mainPopularItem = new MainPopularItem();

                                mainFestivalItem.setTitle(jsonArrayF.get(i).getAsJsonObject().get("title").toString().replaceAll("\"", ""));
                                mainFestivalItem.setTitle_eng(jsonArrayF.get(i).getAsJsonObject().get("title_eng").toString().replaceAll("\"", ""));
                                if(jsonArrayF.get(i).getAsJsonObject().get("image").toString().equals("null")){
                                    mainFestivalItem.setImage("NoImage");
                                } else {
                                    mainFestivalItem.setImage(jsonArrayF.get(i).getAsJsonObject().get("image").toString());
                                }
                                mainFestivalItem.setContent_id(jsonArrayF.get(i).getAsJsonObject().get("content_id").getAsInt());
                                mainFestivalItem.setContent_type_id(jsonArrayF.get(i).getAsJsonObject().get("content_type_id").getAsInt());
                                arrayListF.add(mainFestivalItem);



                                mainMonthlyItem.setTitle(jsonArrayM.get(i).getAsJsonObject().get("title").toString().replaceAll("\"", ""));
                                mainMonthlyItem.setTitle_eng(jsonArrayM.get(i).getAsJsonObject().get("title_eng").toString());
                                mainMonthlyItem.setContent_id(jsonArrayM.get(i).getAsJsonObject().get("content_id").getAsInt());
                                mainMonthlyItem.setContent_type_id(jsonArrayM.get(i).getAsJsonObject().get("content_type_id").getAsInt());
                                mainMonthlyItem.setAddress(jsonArrayM.get(i).getAsJsonObject().get("address").toString());
                                Log.d("xxx",jsonArrayM.get(i).getAsJsonObject().get("image").toString());
                                if(jsonArrayM.get(i).getAsJsonObject().get("image").toString().equals("null")){
                                    mainMonthlyItem.setImage("NoImage");
                                    Log.d("xxxxx","NoImage저장");
                                } else {
                                    mainMonthlyItem.setImage(jsonArrayM.get(i).getAsJsonObject().get("image").toString());
                                }
                                mainMonthlyItem.setWish_count(jsonArrayM.get(i).getAsJsonObject().get("wish_count").getAsInt());
                                mainMonthlyItem.setWished(jsonArrayM.get(i).getAsJsonObject().get("wished").getAsBoolean());
                                arrayListM.add(mainMonthlyItem);



                                mainPopularItem.setTitle(jsonArrayP.get(i).getAsJsonObject().get("title").toString().replaceAll("\"", ""));
                                mainPopularItem.setTitle_eng(jsonArrayP.get(i).getAsJsonObject().get("title_eng").toString());
                                mainPopularItem.setContent_id(jsonArrayP.get(i).getAsJsonObject().get("content_id").getAsInt());
                                mainPopularItem.setContent_type_id(jsonArrayP.get(i).getAsJsonObject().get("content_type_id").getAsInt());
                                mainPopularItem.setAddress(jsonArrayP.get(i).getAsJsonObject().get("address").toString());
                                if(jsonArrayP.get(i).getAsJsonObject().get("image").toString().equals("null")){
                                    mainPopularItem.setImage("NoImage");
                                } else {
                                    mainPopularItem.setImage(jsonArrayP.get(i).getAsJsonObject().get("image").toString());
                                }
                                mainPopularItem.setWish_count(jsonArrayP.get(i).getAsJsonObject().get("wish_count").getAsInt());
                                mainPopularItem.setWished(jsonArrayP.get(i).getAsJsonObject().get("wished").getAsBoolean());
                                arrayListP.add(mainPopularItem);
                            }
                            MainFestivalAdapter adapterF = new MainFestivalAdapter(getActivity().getLayoutInflater(), arrayListF, getActivity());
                            MainMonthlyAdapter adapterM = new MainMonthlyAdapter(getActivity().getLayoutInflater(), arrayListM, getActivity());
                            MainPopularAdapter adapterP = new MainPopularAdapter(getActivity().getLayoutInflater(), arrayListP, getActivity());
                            Log.d("sibal2", arrayListF.get(0).getTitle()+"");
                            viewPagerFestival.setAdapter(adapterF);
                            pageIndicatorView.setViewPager(viewPagerFestival);
                            pageIndicatorView.setAnimationType(AnimationType.FILL);
                            viewPagerMonthly.setAdapter(adapterM);
                            viewPagerPopular.setAdapter(adapterP);
                        } else {
                            Log.d("Main_fragment_error", "ang gi mo thi");
                        }
                    }
                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        t.printStackTrace();
                    }
                });
            }
        });
        return viewGroup;
    }
}
