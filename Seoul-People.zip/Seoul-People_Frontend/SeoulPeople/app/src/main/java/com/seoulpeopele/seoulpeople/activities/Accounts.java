package com.seoulpeopele.seoulpeople.activities;

import android.content.SharedPreferences;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.seoulpeopele.seoulpeople.R;

public class Accounts extends AppCompatActivity implements View.OnClickListener {

    private final int FRAGMENT_SIGNIN = 1;
    private final int FRAGMENT_SIGNUP = 2;

    private Button tab_signup, tab_signin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_accounts);

        tab_signup = (Button)findViewById(R.id.tab_signup);
        tab_signin = (Button)findViewById(R.id.tab_signin);

        tab_signup.setOnClickListener(this);
        tab_signin.setOnClickListener(this);

        callFragment(FRAGMENT_SIGNIN);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.tab_signin:
                callFragment(FRAGMENT_SIGNIN);
                break;

            case R.id.tab_signup:
                callFragment(FRAGMENT_SIGNUP);
                break;
        }
    }

    private void callFragment(int frament_no) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        switch(frament_no) {
            case 1:
                SharedPreferences sharedPreferences = getSharedPreferences("SP", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.apply();
                Signin fragment_signinFirst = new Signin();
                transaction.replace(R.id.fragment_container_accounts, fragment_signinFirst);
                transaction.commit();
                break;

            case 2:
                transaction.replace(R.id.fragment_container_accounts, new Signup());
                transaction.commit();
                break;
        }
    }
}
