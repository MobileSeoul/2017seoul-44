package com.seoulpeopele.seoulpeople.activities;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.seoulpeopele.seoulpeople.R;
import com.seoulpeopele.seoulpeople.adapter.SignUpAdapter;

/**
 * Created by geni on 2017. 10. 24..
 */

public class Signup extends Fragment {
    ViewPager viewPager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.f_sign_up_viewpager, container, false);
        viewPager = (ViewPager) view.findViewById(R.id.signup_viewpager);
        viewPager.setAdapter(new SignUpAdapter(getContext(), view, getActivity().getSupportFragmentManager().beginTransaction()));
        return view;
    }

    public static void nextBtn(View view){
        ViewPager viewPager = (ViewPager) view.findViewById(R.id.signup_viewpager);
        viewPager.setCurrentItem(1, true);
    }

    public static void goEmailCertify(View view){
        ViewPager viewPager = (ViewPager) view.findViewById(R.id.signup_viewpager);
        viewPager.setCurrentItem(2, true);
    }
}
